#Requires -Version 5.1
#Requires -RunAsAdministrator

[CmdletBinding()]
param(
    [ValidateSet('Both', 'Chrome', 'Edge')]
    [string]$Browser = 'Both',
    [switch]$NormalInstalled,
    [switch]$AllowUnmanaged
)

$ErrorActionPreference = 'Stop'
$ExtensionId = 'fbindmncklhddnehgbmnbhbkmchdaejk'
$ExtensionVersion = '1.4.16'
$UpdateUrl = 'https://raw.githubusercontent.com/GodSyndRome/rCn-extension-releases/main/extension/chromium/update.xml'

function Test-RcnManagedDevice {
    $computer = Get-CimInstance -ClassName Win32_ComputerSystem
    $domainJoined = [bool]$computer.PartOfDomain
    $dsreg = (& dsregcmd /status 2>$null) -join "`n"
    $azureAdJoined = $dsreg -match 'AzureAdJoined\s*:\s*YES'
    return $domainJoined -or $azureAdJoined
}

function Set-RcnExtensionPolicy {
    param([Parameter(Mandatory)][string]$PolicyPath)

    New-Item -Path $PolicyPath -Force | Out-Null
    $raw = (Get-ItemProperty -Path $PolicyPath -Name ExtensionSettings -ErrorAction SilentlyContinue).ExtensionSettings
    if ([string]::IsNullOrWhiteSpace($raw)) {
        $settings = [pscustomobject]@{}
    } else {
        try { $settings = $raw | ConvertFrom-Json }
        catch { throw "Mevcut ExtensionSettings politikası geçerli JSON değil: $PolicyPath" }
    }

    $mode = if ($NormalInstalled) { 'normal_installed' } else { 'force_installed' }
    $entry = [pscustomobject]@{
        installation_mode = $mode
        update_url = $UpdateUrl
        override_update_url = $true
        minimum_version_required = $ExtensionVersion
    }
    $settings | Add-Member -NotePropertyName $ExtensionId -NotePropertyValue $entry -Force
    $json = $settings | ConvertTo-Json -Compress -Depth 12
    New-ItemProperty -Path $PolicyPath -Name ExtensionSettings -PropertyType String -Value $json -Force | Out-Null
}

if (-not $AllowUnmanaged -and -not (Test-RcnManagedDevice)) {
    throw @'
Bu bilgisayar Active Directory veya Microsoft Entra ID ile yönetiliyor görünmüyor.
Chrome ve Edge, mağaza dışı özel eklentinin zorunlu kurulumunu yönetilmeyen Windows cihazlarında engelleyebilir.
Kurumsal cihaz yönetimini tamamlayın veya yalnız test amacıyla -AllowUnmanaged parametresini kullanın.
'@
}

if ($Browser -in @('Both', 'Chrome')) {
    Set-RcnExtensionPolicy -PolicyPath 'HKLM:\SOFTWARE\Policies\Google\Chrome'
}
if ($Browser -in @('Both', 'Edge')) {
    Set-RcnExtensionPolicy -PolicyPath 'HKLM:\SOFTWARE\Policies\Microsoft\Edge'
}

Write-Host "rCn eklenti politikası uygulandı." -ForegroundColor Green
Write-Host "Eklenti kimliği: $ExtensionId"
Write-Host "Sürüm: $ExtensionVersion"
Write-Host "Chrome veya Edge'i tamamen kapatıp yeniden açın."
