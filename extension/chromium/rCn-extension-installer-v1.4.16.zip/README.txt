rCn Tarayıcı Eklentisi 1.4.16 – GitHub Otomatik Güncelleme Kurulumu

Extension ID: fbindmncklhddnehgbmnbhbkmchdaejk
Update URL: https://raw.githubusercontent.com/GodSyndRome/rCn-extension-releases/main/extension/chromium/update.xml

Kurulum:
1. ZIP'i klasöre çıkarın.
2. PowerShell'i Yönetici olarak açın.
3. Klasörde çalıştırın:
   PowerShell -ExecutionPolicy Bypass -File .\Install-rCnExtension.ps1
4. Chrome ve Edge'i tamamen kapatıp yeniden açın.

Yalnız test için yönetilmeyen Windows'ta:
   PowerShell -ExecutionPolicy Bypass -File .\Install-rCnExtension.ps1 -AllowUnmanaged

Notlar:
- Chrome/Edge geliştirici modunda "Paketlenmemiş öğe yükle" ile kurulan kopya otomatik güncellenmez.
- Otomatik güncelleme, aynı sabit CRX kimliğiyle policy üzerinden kurulan eklenti için geçerlidir.
- Mağaza dışı zorunlu kurulumun uygulanması tarayıcı/Windows kurumsal politika şartlarına bağlıdır.
- Özel imzalama anahtarı bu pakette bulunmaz.

Kaldırma:
   PowerShell -ExecutionPolicy Bypass -File .\Uninstall-rCnExtension.ps1
