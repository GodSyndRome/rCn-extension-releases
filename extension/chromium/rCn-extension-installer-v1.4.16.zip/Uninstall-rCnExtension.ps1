#Requires -Version 5.1
#Requires -RunAsAdministrator

[CmdletBinding()]
param(
    [ValidateSet('Both', 'Chrome', 'Edge')]
    [string]$Browser = 'Both'
)

$ErrorActionPreference = 'Stop'
$ExtensionId = 'fbindmncklhddnehgbmnbhbkmchdaejk'

function Remove-RcnExtensionPolicy {
    param([Parameter(Mandatory)][string]$PolicyPath)
    if (-not (Test-Path $PolicyPath)) { return }
    $raw = (Get-ItemProperty -Path $PolicyPath -Name ExtensionSettings -ErrorAction SilentlyContinue).ExtensionSettings
    if ([string]::IsNullOrWhiteSpace($raw)) { return }
    try { $settings = $raw | ConvertFrom-Json }
    catch { throw "Mevcut ExtensionSettings politikası geçerli JSON değil: $PolicyPath" }
    $settings.PSObject.Properties.Remove($ExtensionId)
    if ($settings.PSObject.Properties.Count -eq 0) {
        Remove-ItemProperty -Path $PolicyPath -Name ExtensionSettings -ErrorAction SilentlyContinue
    } else {
        $json = $settings | ConvertTo-Json -Compress -Depth 12
        Set-ItemProperty -Path $PolicyPath -Name ExtensionSettings -Value $json
    }
}

if ($Browser -in @('Both', 'Chrome')) { Remove-RcnExtensionPolicy -PolicyPath 'HKLM:\SOFTWARE\Policies\Google\Chrome' }
if ($Browser -in @('Both', 'Edge')) { Remove-RcnExtensionPolicy -PolicyPath 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' }
Write-Host "rCn eklenti politikası kaldırıldı. Tarayıcıyı yeniden başlatın." -ForegroundColor Green
