import './webextCompat.js'
import {
  RCN_CAPTURE_MESSAGE,
  RCN_MIKRO_ADAPTER_KEY,
  RCN_MIKRO_PERMISSION_SCOPE,
  RCN_MIKRO_ORIGIN,
  sha256Hex,
  validateBridgePayload,
} from './lib/integrationContract.js'
import {
  RCN_APP_TAB_PATTERNS,
  RCN_PRIMARY_APP_URL,
  isAllowedRcnAppOrigin,
  isPreferredRcnUrl,
} from './lib/appOrigins.js'
import {
  claimPairing,
  exchangeApprovedPairing,
  getPublicDeviceSession,
  pendingPairingState,
  reportFilledJob,
  reportTargetResult,
  revokeLocalDeviceSession,
  validateServerJob,
} from './lib/deviceSession.js'
import { normalizeMikroProfile } from './lib/mikroProfile.js'

const PROFILE_KEY = 'rcn.integrationProfiles'
const LEDGER_KEY = 'rcn.operationLedger'
const SESSION_PREFIX = 'rcn.pending.'
const SAVE_ARM_PREFIX = 'rcn.saveArm.'
const SAVE_ARM_TTL_MS = 90 * 1000
const HOTEL_QUEUE_KEY = 'rcn.hotelInvoiceQueue.v1'
const HOTEL_IDENTITY_NO = '11111111111'
const HOTEL_TAX_TYPE = 'Konaklama V'
const MIKRO_CONTENT_FILES = [
  'webextCompat.js',
  'content/mikroAdapter.js',
  'content/mikroRuntimePatch.js',
  'content/mikroTaxPatch136.js',
  'content/targetRunner.js',
]

function senderOrigin(sender) {
  try {
    return new URL(sender?.url || sender?.tab?.url || '').origin
  } catch (_) {
    return ''
  }
}

function senderTabId(sender) {
  const value = Number(sender?.tab?.id)
  return Number.isInteger(value) && value >= 0 ? value : null
}

function saveArmKey(tabId) {
  return `${SAVE_ARM_PREFIX}${tabId}`
}

async function queryRcnTabs() {
  const tabs = await chrome.tabs.query({ url: RCN_APP_TAB_PATTERNS })
  return [...new Map(tabs.map((tab) => [tab.id, tab])).values()]
    .sort((first, second) => Number(isPreferredRcnUrl(second.url)) - Number(isPreferredRcnUrl(first.url)))
}

async function getProfiles() {
  const stored = await chrome.storage.local.get(PROFILE_KEY)
  const profiles = Array.isArray(stored[PROFILE_KEY]) ? stored[PROFILE_KEY] : []
  const index = profiles.findIndex((profile) => profile?.key === RCN_MIKRO_ADAPTER_KEY)
  const current = index >= 0 ? profiles[index] : null
  const normalized = normalizeMikroProfile(current)
  if (current === normalized) return profiles
  const next = index >= 0
    ? profiles.map((profile, profileIndex) => profileIndex === index ? normalized : profile)
    : [...profiles, normalized]
  await chrome.storage.local.set({ [PROFILE_KEY]: next })
  return next
}

async function getMikroProfile() {
  return (await getProfiles()).find((profile) => profile.key === RCN_MIKRO_ADAPTER_KEY) || normalizeMikroProfile(null)
}

async function getLedger() {
  const stored = await chrome.storage.local.get(LEDGER_KEY)
  return stored[LEDGER_KEY] && typeof stored[LEDGER_KEY] === 'object' ? stored[LEDGER_KEY] : {}
}

async function setLedgerEntry(operationKey, entry) {
  const ledger = await getLedger()
  ledger[operationKey] = entry
  await chrome.storage.local.set({ [LEDGER_KEY]: ledger })
}

async function requireHotelSession() {
  const session = await getPublicDeviceSession()
  if (!session) throw new Error('Hotel faturası için önce rCn web hesabıyla cihaz eşleştirmesini tamamlayın.')
  if (!(session.permissionScopes || []).includes(RCN_MIKRO_PERMISSION_SCOPE)) {
    throw new Error('Bu cihazın Mikro ePortal taslağı hazırlama yetkisi yok.')
  }
  return session
}

async function getHotelQueue() {
  const stored = await chrome.storage.local.get(HOTEL_QUEUE_KEY)
  const queue = stored[HOTEL_QUEUE_KEY]
  return queue && queue.version === 1 && Array.isArray(queue.rows) ? queue : null
}

async function getVisibleHotelQueue() {
  const [queue, session] = await Promise.all([getHotelQueue(), getPublicDeviceSession()])
  if (!queue || !session || queue.companyId !== session.companyId || queue.deviceId !== session.deviceId) return null
  return queue
}

function cleanHotelText(value, label) {
  const result = String(value ?? '').trim().replace(/\s+/g, ' ')
  if (!result) throw new Error(`${label} zorunludur.`)
  return result.slice(0, 100)
}

function cleanHotelIdentityNo(value) {
  const digits = String(value || '').replace(/\D/g, '')
  if (digits.length !== 11) throw new Error('Hotel TCKN değeri 11 haneli olmalıdır.')
  return digits
}

function cleanHotelDescription(value) {
  return String(value ?? '')
    .replace(/\r\n?/g, '\n')
    .split('\n')
    .map((line) => line.trim().replace(/[ \t]+/g, ' '))
    .filter(Boolean)
    .join('\n')
    .slice(0, 1000)
}

async function importHotelQueue(message) {
  const session = await requireHotelSession()
  const inputRows = Array.isArray(message.rows) ? message.rows : []
  if (!inputRows.length || inputRows.length > 5000) throw new Error('Hotel listesi 1 ile 5000 kişi arasında olmalıdır.')
  const city = cleanHotelText(message.city, 'İl')
  const district = cleanHotelText(message.district, 'İlçe')
  const batchId = crypto.randomUUID()
  const rows = inputRows.map((row, index) => {
    const grossAmount = Math.round(Number(row?.grossAmount) * 100) / 100
    if (!Number.isFinite(grossAmount) || grossAmount <= 0 || grossAmount > 1000000000) throw new Error(`${index + 1}. kişinin tutarı geçersiz.`)
    return {
      id: `${batchId}:${index + 1}`,
      order: index + 1,
      identityNo: cleanHotelIdentityNo(row?.identityNo || HOTEL_IDENTITY_NO),
      identityMode: row?.identityMode === 'tckn' ? 'tckn' : 'foreign',
      firstName: cleanHotelText(row?.firstName, `${index + 1}. kişinin adı`),
      lastName: cleanHotelText(row?.lastName, `${index + 1}. kişinin soyadı`),
      grossAmount,
      unitPrice: Number((grossAmount / 1.11).toFixed(3)),
      stays: Array.isArray(row?.stays) ? row.stays.slice(0, 180).map((stay) => ({
        date: String(stay?.date || '').slice(0, 10),
        rooms: Math.max(0, Math.min(999, Number(stay?.rooms) || 0)),
      })).filter((stay) => stay.date && stay.rooms > 0) : [],
      description: cleanHotelDescription(row?.description),
      status: 'pending',
      filledAt: null,
    }
  })
  const queue = {
    version: 1,
    batchId,
    companyId: session.companyId,
    branchId: session.branchId || null,
    deviceId: session.deviceId,
    fileName: String(message.fileName || 'hotel-faturalari.xlsx').slice(0, 180),
    templateKey: String(message.templateKey || 'auto').slice(0, 40),
    templateLabel: String(message.templateLabel || '').slice(0, 160),
    city,
    district,
    importedAt: new Date().toISOString(),
    rows,
  }
  await chrome.storage.local.set({ [HOTEL_QUEUE_KEY]: queue })
  return queue
}

function makeHotelJob(queue, row, session) {
  const operationKey = `hotel-excel:${row.id}`
  const totalTax = Math.round((row.grossAmount - row.unitPrice) * 100) / 100
  return {
    operationKey,
    adapterKey: RCN_MIKRO_ADAPTER_KEY,
    permissionScope: RCN_MIKRO_PERMISSION_SCOPE,
    companyId: session.companyId,
    branchId: session.branchId || null,
    deviceId: session.deviceId,
    localHotelBatch: true,
    hotelBatchId: queue.batchId,
    hotelRowId: row.id,
    issuedAt: new Date().toISOString(),
    invoice: {
      operation: 'create_invoice_draft',
      integration: RCN_MIKRO_ADAPTER_KEY,
      source: { type: 'hotel_excel', id: row.id },
      document: { type: 'e_archive', label: 'e-Arşiv' },
      scenario: { key: 'normal_sale', adapterValue: 'e_archive' },
      recipient: {
        title: `${row.firstName} ${row.lastName}`,
        firstName: row.firstName,
        lastName: row.lastName,
        identityNo: row.identityNo || HOTEL_IDENTITY_NO,
        city: queue.city,
        district: queue.district,
      },
      lines: [{
        name: 'Konaklama',
        quantity: 1,
        unit: 'Gün',
        unitPrice: row.unitPrice,
        vatRate: 10,
        sctRate: 0,
        taxType: HOTEL_TAX_TYPE,
        description: row.description || '',
      }],
      totals: { net: row.unitPrice, tax: totalTax, gross: row.grossAmount },
      payment: { label: 'Belirtilmedi' },
      note: '',
    },
  }
}

async function openNextHotelInvoice() {
  const session = await requireHotelSession()
  const queue = await getVisibleHotelQueue()
  if (!queue) throw new Error('Bu firma ve cihaza ait Hotel listesi bulunamadı.')
  const row = queue.rows.find((item) => item.status !== 'filled')
  if (!row) throw new Error('Hotel listesindeki bütün kişiler dolduruldu.')
  if (row.status === 'prepared') throw new Error(`${row.firstName} ${row.lastName} formu hazır. Mikro ePortal’da “Gönder” düğmesine tıklamadan sıradaki kişiye geçilemez.`)
  const profile = await getMikroProfile()
  if (!profile.enabled) throw new Error('Mikro ePortal entegrasyon profili pasif.')
  if (new URL(profile.draftUrl).origin !== RCN_MIKRO_ORIGIN || profile.origin !== RCN_MIKRO_ORIGIN) throw new Error('Mikro ePortal hedef adresi doğrulanamadı.')
  const tabs = await chrome.tabs.query({ url: `${RCN_MIKRO_ORIGIN}/*` })
  const tab = tabs[0] || await chrome.tabs.create({ url: profile.draftUrl, active: true })
  if (tabs[0]) await chrome.tabs.update(tab.id, { active: true })
  await waitForTab(tab.id)
  const job = makeHotelJob(queue, row, session)
  const response = await sendPreviewToTarget(tab, { type: 'RCN_PREVIEW_JOB', job, profile })
  if (!response?.ok) throw new Error(response?.error || 'Hotel fatura önizlemesi açılamadı.')
  await setLedgerEntry(job.operationKey, {
    status: 'hotel_previewed',
    companyId: session.companyId,
    branchId: session.branchId || null,
    deviceId: session.deviceId,
    sourceType: 'hotel_excel',
    sourceId: row.id,
    recipientTitle: job.invoice.recipient.title,
    total: row.grossAmount,
    selectorVersion: profile.selectorVersion,
    previewedAt: new Date().toISOString(),
    tabId: tab.id,
  })
  return { tabId: tab.id, recipientTitle: job.invoice.recipient.title, grossAmount: row.grossAmount }
}

async function markHotelPrepared(message, sender) {
  if (senderOrigin(sender) !== RCN_MIKRO_ORIGIN) throw new Error('Hotel form sonucu yalnız doğrulanmış Mikro ePortal sekmesinden kabul edilir.')
  const session = await requireHotelSession()
  const queue = await getVisibleHotelQueue()
  if (!queue || queue.batchId !== String(message.hotelBatchId || '')) throw new Error('Hotel listesi değişmiş; ilerleme kaydedilmedi.')
  const row = queue.rows.find((item) => item.id === String(message.hotelRowId || ''))
  if (!row) throw new Error('Doldurulan kişi güncel Hotel listesinde bulunamadı.')
  if (row.status === 'prepared' || row.status === 'filled') return queue
  const current = queue.rows.find((item) => item.status !== 'filled')
  if (current?.id !== row.id) throw new Error('Hotel listesi sırası değişmiş; ilerleme kaydedilmedi.')
  if (message.payableTotalVerified !== true) throw new Error('Ödenecek tutar doğrulanmadan kişi hazırlanmış sayılamaz.')
  row.status = 'prepared'
  row.preparedAt = new Date().toISOString()
  row.selectorVersion = String(message.selectorVersion || 'unknown')
  row.payableTotalVerified = true
  await chrome.storage.local.set({ [HOTEL_QUEUE_KEY]: queue })
  const operationKey = `hotel-excel:${row.id}`
  const ledger = await getLedger()
  await setLedgerEntry(operationKey, {
    ...(ledger[operationKey] || {}),
    status: 'hotel_form_prepared',
    writtenFieldCount: Number(message.writtenFieldCount) || 0,
    payableTotalVerified: true,
    preparedAt: row.preparedAt,
    tabId: senderTabId(sender),
    companyId: session.companyId,
  })
  return queue
}

async function markHotelSendClicked(message, sender) {
  if (senderOrigin(sender) !== RCN_MIKRO_ORIGIN) throw new Error('Hotel gönderim adımı yalnız doğrulanmış Mikro ePortal sekmesinden kabul edilir.')
  const session = await requireHotelSession()
  const queue = await getVisibleHotelQueue()
  if (!queue || queue.batchId !== String(message.hotelBatchId || '')) throw new Error('Hotel listesi değişmiş; sıra ilerletilmedi.')
  const row = queue.rows.find((item) => item.id === String(message.hotelRowId || ''))
  if (!row || row.status !== 'prepared' || row.payableTotalVerified !== true) throw new Error('Hotel faturası doğrulanmış biçimde hazırlanmadan sıra ilerletilemez.')
  const current = queue.rows.find((item) => item.status !== 'filled')
  if (current?.id !== row.id) throw new Error('Hotel listesi sırası değişmiş; sıra ilerletilmedi.')
  row.status = 'filled'
  row.filledAt = new Date().toISOString()
  row.userSendClickedAt = row.filledAt
  await chrome.storage.local.set({ [HOTEL_QUEUE_KEY]: queue })
  const operationKey = `hotel-excel:${row.id}`
  const ledger = await getLedger()
  await setLedgerEntry(operationKey, {
    ...(ledger[operationKey] || {}),
    status: 'hotel_user_send_clicked',
    userSendClickedAt: row.userSendClickedAt,
    tabId: senderTabId(sender),
    companyId: session.companyId,
  })
  return queue
}

async function clearHotelQueue() {
  await requireHotelSession()
  await chrome.storage.local.remove(HOTEL_QUEUE_KEY)
  return null
}

async function updateBadge() {
  const values = await chrome.storage.session.get(null)
  const count = Object.keys(values).filter((key) => key.startsWith(SESSION_PREFIX)).length
  await chrome.action.setBadgeText({ text: count ? String(Math.min(count, 99)) : '' })
  if (count) await chrome.action.setBadgeBackgroundColor({ color: '#60ff58' })
}

async function captureJob(payload, sender) {
  const origin = senderOrigin(sender)
  if (!isAllowedRcnAppOrigin(origin)) throw new Error('İş yalnız doğrulanmış rCn adresinden alınabilir.')
  const job = validateBridgePayload(payload)
  const hash = await sha256Hex({
    companyId: job.companyId,
    branchId: job.branchId,
    deviceId: job.deviceId,
    draftId: job.draftId,
    operationKey: job.operationKey,
    invoice: job.invoice,
  })
  const pendingKey = `${SESSION_PREFIX}${job.operationKey}`
  const [pending, ledger, publicSession] = await Promise.all([
    chrome.storage.session.get(pendingKey),
    getLedger(),
    getPublicDeviceSession(),
  ])
  const existingPending = pending[pendingKey]
  if (existingPending?.hash === hash) return { operationKey: job.operationKey, duplicate: true }
  if (!publicSession) throw new Error('rCn eklentisi web hesabınızla eşleştirilmemiş. Önce cihaz eşleştirmesini tamamlayın.')
  if (publicSession.deviceId !== job.deviceId || publicSession.companyId !== job.companyId || (publicSession.branchId || null) !== (job.branchId || null)) {
    throw new Error('İş firma, şube veya cihaz oturumu kapsamıyla uyuşmuyor.')
  }
  const existing = ledger[job.operationKey]
  if (['draft_created', 'verified', 'result_pending'].includes(existing?.status)) throw new Error('Bu kaynak kayıt için ePortal taslağı daha önce oluşturulmuş veya doğrulama bekliyor.')
  if (existing?.hash && existing.hash !== hash && ['captured', 'previewed', 'filled'].includes(existing.status)) {
    throw new Error('Aynı işlem anahtarı için farklı veri paketi algılandı. rCn kaydını yenileyip tekrar hazırlayın.')
  }

  await validateServerJob(job)
  await chrome.storage.session.set({ [pendingKey]: { job, hash } })
  await setLedgerEntry(job.operationKey, {
    hash,
    status: existing?.status === 'filled' ? 'filled' : 'captured',
    jobId: job.jobId,
    companyId: job.companyId,
    branchId: job.branchId,
    deviceId: job.deviceId,
    draftId: job.draftId,
    sourceType: job.invoice.source.type,
    sourceId: job.invoice.source.id,
    recipientTitle: job.invoice.recipient.title,
    total: job.invoice.totals.gross,
    capturedAt: new Date().toISOString(),
  })
  await updateBadge()
  return { operationKey: job.operationKey, duplicate: Boolean(existing?.hash === hash) }
}

async function listPendingJobs() {
  const values = await chrome.storage.session.get(null)
  const now = Date.now()
  const expiredKeys = []
  const jobs = Object.entries(values)
    .filter(([key]) => key.startsWith(SESSION_PREFIX))
    .map(([key, value]) => {
      const job = value?.job
      const expiresAt = Date.parse(job?.expiresAt || '')
      if (Number.isFinite(expiresAt) && expiresAt <= now) expiredKeys.push(key)
      return { key, job }
    })
    .filter(({ job }) => job && Date.parse(job.expiresAt || '') > now)
    .map(({ job }) => job)
    .sort((first, second) => Date.parse(second.issuedAt) - Date.parse(first.issuedAt))
  if (expiredKeys.length) {
    await chrome.storage.session.remove(expiredKeys)
    await updateBadge()
  }
  return jobs
}

async function getPendingJob(operationKey) {
  const key = `${SESSION_PREFIX}${operationKey}`
  const stored = await chrome.storage.session.get(key)
  return stored[key]?.job || null
}

async function waitForTab(tabId, timeoutMs = 20000) {
  const current = await chrome.tabs.get(tabId)
  if (current.status === 'complete') return current
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener)
      reject(new Error('Mikro ePortal sayfası zamanında yüklenmedi.'))
    }, timeoutMs)
    function listener(updatedTabId, changeInfo, tab) {
      if (updatedTabId !== tabId || changeInfo.status !== 'complete') return
      clearTimeout(timeout)
      chrome.tabs.onUpdated.removeListener(listener)
      resolve(tab)
    }
    chrome.tabs.onUpdated.addListener(listener)
  })
}

function isMissingReceiverError(error) {
  return /receiving end does not exist|could not establish connection|message port closed/i.test(String(error?.message || error || ''))
}

async function sendPreviewToTarget(tab, message) {
  try {
    return await chrome.tabs.sendMessage(tab.id, message)
  } catch (error) {
    if (!isMissingReceiverError(error)) throw error
    const tabUrl = new URL(tab.url || '')
    if (tabUrl.origin !== RCN_MIKRO_ORIGIN) throw new Error('Mikro ePortal hedef sekmesi doğrulanamadı.')
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: MIKRO_CONTENT_FILES })
    return chrome.tabs.sendMessage(tab.id, message)
  }
}

async function openTarget(operationKey) {
  const job = await getPendingJob(operationKey)
  if (!job) throw new Error('Aktarım işi bulunamadı veya süresi doldu. rCn üzerinden tekrar hazırlayın.')
  const session = await getPublicDeviceSession()
  if (!session || session.deviceId !== job.deviceId) throw new Error('Bu işin bağlı cihaz oturumu artık geçerli değil.')
  const profile = await getMikroProfile()
  if (!profile.enabled) throw new Error('Mikro ePortal entegrasyon profili pasif.')
  if (new URL(profile.draftUrl).origin !== RCN_MIKRO_ORIGIN || profile.origin !== RCN_MIKRO_ORIGIN) {
    throw new Error('Mikro ePortal hedef adresi doğrulanamadı.')
  }

  const tabs = await chrome.tabs.query({ url: `${RCN_MIKRO_ORIGIN}/*` })
  const tab = tabs[0] || await chrome.tabs.create({ url: profile.draftUrl, active: true })
  if (tabs[0]) await chrome.tabs.update(tab.id, { active: true })
  await waitForTab(tab.id)
  let response
  try {
    response = await sendPreviewToTarget(tab, { type: 'RCN_PREVIEW_JOB', job, profile })
  } catch (error) {
    if (isMissingReceiverError(error)) throw new Error('Mikro ePortal sekmesi rCn eklentisine bağlanamadı. Sekmeyi yenileyip tekrar deneyin.')
    throw error
  }
  if (!response?.ok) throw new Error(response?.error || 'Mikro ePortal önizlemesi açılamadı.')
  const ledger = await getLedger()
  await setLedgerEntry(operationKey, { ...(ledger[operationKey] || {}), status: 'previewed', selectorVersion: profile.selectorVersion, previewedAt: new Date().toISOString(), tabId: tab.id })
  return { tabId: tab.id, selectorVersion: profile.selectorVersion }
}

async function markFilled(message, sender) {
  if (senderOrigin(sender) !== RCN_MIKRO_ORIGIN) throw new Error('Form sonucu doğrulanmış Mikro ePortal sekmesinden gelmedi.')
  const job = await getPendingJob(message.operationKey)
  if (!job) throw new Error('Aktarım işi bulunamadı veya süresi doldu.')
  const profile = await getMikroProfile()
  const selectorVersion = message.selectorVersion || profile.selectorVersion || 'unknown'
  await reportFilledJob({
    operationKey: message.operationKey,
    writtenFieldCount: Number(message.writtenFieldCount) || 0,
    selectorVersion,
    pageUrl: sender?.tab?.url || sender?.url || '',
  })
  const ledger = await getLedger()
  await setLedgerEntry(message.operationKey, {
    ...(ledger[message.operationKey] || {}),
    status: 'filled',
    writtenFieldCount: Number(message.writtenFieldCount) || 0,
    selectorVersion,
    filledAt: new Date().toISOString(),
    tabId: senderTabId(sender),
  })
  return { ok: true }
}

async function armDraftSave(message, sender) {
  if (senderOrigin(sender) !== RCN_MIKRO_ORIGIN) throw new Error('Taslak kaydetme kanıtı yalnız Mikro ePortal sekmesinden kabul edilir.')
  const tabId = senderTabId(sender)
  if (tabId == null) throw new Error('Mikro ePortal sekmesi doğrulanamadı.')
  const operationKey = String(message.operationKey || '').trim()
  const job = await getPendingJob(operationKey)
  if (!job) throw new Error('Aktarım işi bulunamadı veya süresi doldu.')
  const ledger = await getLedger()
  if (ledger[operationKey]?.status !== 'filled') throw new Error('Form doldurma sonucu rCn sunucusunda doğrulanmadan Mikro taslağı tamamlanmış sayılamaz.')
  const serial = String(message.serial || '').trim().replace(/[^a-zA-Z0-9_$İIıŞşĞğÜüÖöÇç-]/g, '').slice(0, 12)
  const number = String(message.number || '').trim().replace(/[^0-9]/g, '').slice(0, 12)
  if (!serial || !number) throw new Error('Mikro Taslak No doğrulanamadı; taslak sonucu rCn’ye işlenmedi.')
  const externalDocumentNo = `${serial}${number}`
  const arm = {
    operationKey,
    externalDocumentNo,
    serial,
    number,
    tabId,
    armedAt: new Date().toISOString(),
    sourceUrl: sender?.tab?.url || sender?.url || '',
  }
  await chrome.storage.session.set({ [saveArmKey(tabId)]: arm })
  await setLedgerEntry(operationKey, { ...(ledger[operationKey] || {}), saveArmedAt: arm.armedAt, externalDocumentNo })
  return { armed: true, externalDocumentNo }
}

function validDraftListRedirect(urlValue) {
  try {
    const url = new URL(urlValue)
    if (url.origin !== RCN_MIKRO_ORIGIN || url.searchParams.get('loadFormData') !== 'true') return false
    const path = url.pathname.replace(/\/+$/, '').toLocaleLowerCase('tr-TR')
    return path.endsWith('/earchive/list') || path.endsWith('/newinvoice/list')
  } catch (_) {
    return false
  }
}

async function completeDraftSaveRedirect(message, sender) {
  if (senderOrigin(sender) !== RCN_MIKRO_ORIGIN) throw new Error('Taslak sonucu yalnız Mikro ePortal sekmesinden kabul edilir.')
  const tabId = senderTabId(sender)
  if (tabId == null) return { ignored: true }
  const pageUrl = message.pageUrl || sender?.tab?.url || sender?.url || ''
  if (!validDraftListRedirect(pageUrl)) return { ignored: true }
  const key = saveArmKey(tabId)
  const stored = await chrome.storage.session.get(key)
  const arm = stored[key]
  if (!arm) return { ignored: true }
  const armedAt = Date.parse(arm.armedAt || '')
  if (!Number.isFinite(armedAt) || Date.now() - armedAt > SAVE_ARM_TTL_MS) {
    await chrome.storage.session.remove(key)
    return { ignored: true, expired: true }
  }
  const job = await getPendingJob(arm.operationKey)
  if (!job) {
    await chrome.storage.session.remove(key)
    throw new Error('Mikro taslağı kaydedildi ancak rCn işlem işi artık bulunamadı; otomatik tamamlanmadı.')
  }
  const ledger = await getLedger()
  if (ledger[arm.operationKey]?.status !== 'filled') throw new Error('Mikro taslağı kaydedildi ancak rCn form doldurma doğrulaması tamamlanmadı.')
  const result = await reportTargetResult({
    operationKey: arm.operationKey,
    externalDocumentNo: arm.externalDocumentNo,
  })
  await setLedgerEntry(arm.operationKey, {
    ...(ledger[arm.operationKey] || {}),
    status: 'result_pending',
    externalDocumentNo: arm.externalDocumentNo,
    resultReportedAt: new Date().toISOString(),
  })
  await chrome.storage.session.remove([key, `${SESSION_PREFIX}${arm.operationKey}`])
  await updateBadge()
  return { accepted: true, externalDocumentNo: arm.externalDocumentNo, server: result }
}

async function getExtensionState() {
  const [jobs, profile, ledger, session, pairing, rcnTabs, targetTabs, hotelQueue] = await Promise.all([
    listPendingJobs(),
    getMikroProfile(),
    getLedger(),
    getPublicDeviceSession(),
    pendingPairingState(),
    queryRcnTabs(),
    chrome.tabs.query({ url: `${RCN_MIKRO_ORIGIN}/*` }),
    getVisibleHotelQueue(),
  ])
  return {
    jobs,
    profile,
    ledger,
    hotelQueue,
    session,
    pendingPairing: pairing,
    tabs: {
      rcn: rcnTabs.map((tab) => ({ id: tab.id, title: tab.title || 'rCn', url: tab.url || '' })),
      targets: targetTabs.map((tab) => ({ id: tab.id, title: tab.title || 'Mikrogroup ePortal', url: tab.url || '' })),
    },
  }
}


function canonicalMikroTaxLabel(value) {
  return String(value ?? '')
    .trim()
    .toLocaleLowerCase('tr-TR')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9çğıöşü]+/gi, '')
}

function allowedMikroTaxLabel(value) {
  const key = canonicalMikroTaxLabel(value)
  if (key === canonicalMikroTaxLabel('Konaklama V')) return 'Konaklama V'
  if (key === canonicalMikroTaxLabel('ÖTV 2. Liste') || key === canonicalMikroTaxLabel('ÖTV 2.LİSTE')) return 'ÖTV 2.LİSTE'
  return ''
}

async function selectMikroTaxInMainWorld(message, sender) {
  if (senderOrigin(sender) !== RCN_MIKRO_ORIGIN) throw new Error('Vergi seçimi yalnız doğrulanmış Mikro ePortal sekmesinden yapılabilir.')
  const tabId = senderTabId(sender)
  if (tabId == null) throw new Error('Mikro ePortal sekmesi doğrulanamadı.')
  const label = allowedMikroTaxLabel(message?.label)
  if (!label) throw new Error('Desteklenmeyen Mikro vergi türü istendi.')

  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    args: [label],
    func: async (targetLabel) => {
      const canonical = (value) => String(value ?? '')
        .trim()
        .toLocaleLowerCase('tr-TR')
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9çğıöşü]+/gi, '')
      const visible = (element) => {
        if (!element) return false
        const style = window.getComputedStyle(element)
        return style.display !== 'none' && style.visibility !== 'hidden'
      }
      const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
      const startedAt = Date.now()

      let select = null
      const selectDeadline = Date.now() + 12000
      while (Date.now() < selectDeadline) {
        select = Array.from(document.querySelectorAll('select#taxType')).find(visible) || null
        if (select) break
        await wait(100)
      }
      if (!select) return { selected: false, stage: 'taxType_not_found', elapsedMs: Date.now() - startedAt }

      // Modal açılış animasyonu ve ng-options digest'i için bilinçli gecikme.
      await wait(1200)

      let option = null
      const optionDeadline = Date.now() + 15000
      let optionAttempts = 0
      while (Date.now() < optionDeadline) {
        optionAttempts += 1
        option = Array.from(select.options || [])
          .find((item) => canonical(item.textContent || item.label) === canonical(targetLabel)) || null
        if (option) break
        await wait(250)
      }
      if (!option) {
        return {
          selected: false,
          stage: 'option_not_found_after_delay',
          optionCount: Number(select.options?.length || 0),
          optionAttempts,
          elapsedMs: Date.now() - startedAt,
        }
      }

      const index = Array.from(select.options || []).indexOf(option)
      const optionValue = String(option.value || '')
      let angularChangeTriggered = false

      for (let attempt = 1; attempt <= 4; attempt += 1) {
        select.focus?.()
        if (index >= 0) select.selectedIndex = index

        try {
          const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value')?.set
          if (setter) setter.call(select, optionValue)
          else select.value = optionValue
        } catch (_) {
          select.value = optionValue
        }
        option.selected = true

        // AngularJS ngOptions'ın kendi selectValueMap mekanizmasını çalıştır.
        try {
          if (window.angular?.element) {
            const angularElement = window.angular.element(select)
            angularElement.val?.(optionValue)
            angularElement.triggerHandler?.('change')
            angularChangeTriggered = true
          }
        } catch (_) {}

        for (const eventName of ['input', 'change']) {
          select.dispatchEvent(new Event(eventName, { bubbles: true, cancelable: true }))
        }
        select.dispatchEvent(new Event('blur', { bubbles: true }))

        await wait(500)

        const selectedOption = select.options?.[select.selectedIndex]
        const selectedText = String(selectedOption?.textContent || selectedOption?.label || '').trim()
        if (canonical(selectedText) === canonical(targetLabel) && String(select.value || '') === optionValue) {
          return {
            selected: true,
            stage: 'dom_selection_verified',
            selectedText,
            selectedValue: optionValue,
            optionCount: Number(select.options?.length || 0),
            optionAttempts,
            attempt,
            angularChangeTriggered,
            elapsedMs: Date.now() - startedAt,
          }
        }

        await wait(500)
      }

      const selectedOption = select.options?.[select.selectedIndex]
      return {
        selected: false,
        stage: 'selection_not_sticky_after_retries',
        selectedText: String(selectedOption?.textContent || selectedOption?.label || '').trim(),
        selectedValue: String(select.value || ''),
        targetValue: optionValue,
        optionCount: Number(select.options?.length || 0),
        optionAttempts,
        angularChangeTriggered,
        elapsedMs: Date.now() - startedAt,
      }
    },
  })

  const result = results?.[0]?.result
  if (!result?.selected) {
    const stage = String(result?.stage || 'unknown')
    const count = Number(result?.optionCount || 0)
    const selectedText = String(result?.selectedText || '-').slice(0, 80)
    const selectedValue = String(result?.selectedValue || '-').slice(0, 80)
    const targetValue = String(result?.targetValue || '-').slice(0, 80)
    const attempts = Number(result?.optionAttempts || 0)
    const angularChange = result?.angularChangeTriggered === true ? 'evet' : 'hayır'
    const elapsed = Number(result?.elapsedMs || 0)
    throw new Error(`Mikro Vergi Türü seçimi doğrulanamadı (${stage}; option: ${count}; seçili: ${selectedText}; value: ${selectedValue}; hedef value: ${targetValue}; Angular change: ${angularChange}; arama: ${attempts}; süre: ${elapsed}ms).`)
  }
  return result
}

async function openRcnWeb() {
  const tabs = await queryRcnTabs()
  if (tabs[0]) {
    await chrome.tabs.update(tabs[0].id, { active: true })
    return { tabId: tabs[0].id }
  }
  const tab = await chrome.tabs.create({ url: RCN_PRIMARY_APP_URL, active: true })
  return { tabId: tab.id }
}

chrome.runtime.onInstalled.addListener(async () => {
  await getProfiles()
  await chrome.storage.session.clear()
  await updateBadge()
})
chrome.runtime.onStartup?.addListener(async () => {
  await getProfiles()
  await chrome.storage.session.clear()
  await updateBadge()
})

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (String(message?.type || '').startsWith('RCN_GIB_')) return false
  ;(async () => {
    if (message?.type === RCN_CAPTURE_MESSAGE) return captureJob(message.payload, sender)
    if (message?.type === 'RCN_GET_STATE') return getExtensionState()
    if (message?.type === 'RCN_OPEN_TARGET') return openTarget(message.operationKey)
    if (message?.type === 'RCN_MARK_FILLED') return markFilled(message, sender)
    if (message?.type === 'RCN_ARM_DRAFT_SAVE') return armDraftSave(message, sender)
    if (message?.type === 'RCN_TARGET_SAVE_REDIRECT') return completeDraftSaveRedirect(message, sender)
    if (message?.type === 'RCN_HOTEL_QUEUE_GET') return getVisibleHotelQueue()
    if (message?.type === 'RCN_HOTEL_QUEUE_IMPORT') return importHotelQueue(message)
    if (message?.type === 'RCN_HOTEL_FILL_NEXT') return openNextHotelInvoice()
    if (message?.type === 'RCN_HOTEL_MARK_PREPARED') return markHotelPrepared(message, sender)
    if (message?.type === 'RCN_HOTEL_MARK_SEND_CLICKED') return markHotelSendClicked(message, sender)
    if (message?.type === 'RCN_MIKRO_SELECT_TAX_MAIN') return selectMikroTaxInMainWorld(message, sender)
    if (message?.type === 'RCN_HOTEL_QUEUE_CLEAR') return clearHotelQueue()
    if (message?.type === 'RCN_CLAIM_PAIRING') {
      if (!isAllowedRcnAppOrigin(senderOrigin(sender))) throw new Error('Eşleştirme yalnız doğrulanmış rCn sekmesinden başlatılabilir.')
      return claimPairing(message.payload)
    }
    if (message?.type === 'RCN_ACCEPT_PAIRING') {
      if (!isAllowedRcnAppOrigin(senderOrigin(sender))) throw new Error('Eşleştirme onayı yalnız doğrulanmış rCn sekmesinden alınabilir.')
      return exchangeApprovedPairing(message.payload)
    }
    if (message?.type === 'RCN_LOGOUT_EXTENSION') {
      await revokeLocalDeviceSession()
      await chrome.storage.local.remove(HOTEL_QUEUE_KEY)
      await chrome.storage.session.clear()
      await updateBadge()
      return { revoked: true }
    }
    if (message?.type === 'RCN_OPEN_WEB') return openRcnWeb()
    throw new Error('Desteklenmeyen eklenti mesajı.')
  })().then((result) => sendResponse({ ok: true, result })).catch((error) => sendResponse({ ok: false, error: error.message || 'Eklenti işlemi tamamlanamadı.' }))
  return true
})
