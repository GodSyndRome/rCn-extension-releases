(() => {
  const api = globalThis.browser ?? globalThis.chrome
  if (!api) throw new Error('rCn WebExtension API bu tarayıcıda kullanılamıyor.')
  if (!globalThis.chrome) globalThis.chrome = api
  if (!globalThis.browser) globalThis.browser = api
  if (!api.storage?.session && api.storage?.local) {
    const fallbackKey = 'rcn.sessionStorageFallback.v1'
    const local = api.storage.local
    const normalizeKeys = (keys) => keys == null ? null : typeof keys === 'string' ? [keys] : Array.isArray(keys) ? keys : typeof keys === 'object' ? Object.keys(keys) : []
    const readAll = async () => { const stored = await local.get(fallbackKey); return stored[fallbackKey] && typeof stored[fallbackKey] === 'object' ? stored[fallbackKey] : {} }
    api.storage.session = {
      async get(keys = null) { const values = await readAll(); const normalized = normalizeKeys(keys); if (normalized === null) return { ...values }; const result = {}; for (const key of normalized) { if (Object.hasOwn(values, key)) result[key] = values[key]; else if (keys && typeof keys === 'object' && !Array.isArray(keys)) result[key] = keys[key] } return result },
      async set(entries) { const values = await readAll(); await local.set({ [fallbackKey]: { ...values, ...entries } }) },
      async remove(keys) { const values = await readAll(); for (const key of normalizeKeys(keys) || []) delete values[key]; await local.set({ [fallbackKey]: values }) },
      async clear() { await local.remove(fallbackKey) },
    }
  }
})()
