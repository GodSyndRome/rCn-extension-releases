const PROFILE_KEY = 'rcn.integrationProfiles'
const MIKRO_ORIGIN = 'https://eportal.mikrogrup.com'
const BUILTIN_SELECTOR_VERSION = 'mikro-eportal-2026.08.13-v3'
const forbiddenKey = /(save|submit|send|approve|cancel|delete|kaydet|gönder|onay|iptal|sil)/i
const requiredSelectorKeys = ['documentType', 'scenario', 'recipientTitle', 'recipientFirstName', 'recipientLastName', 'identityNo', 'taxNo', 'taxOffice', 'city', 'district', 'address', 'lineName', 'lineQuantity', 'lineUnitPrice', 'lineVatRate', 'lineSctRate', 'lineDescription', 'generalNote']
const defaultSelectors = {
  documentType: '@skip',
  scenario: '@skip',
  recipientTitle: '#customerTitle',
  recipientFirstName: '#name',
  recipientLastName: '#surname',
  identityNo: '#taxNumber',
  taxNo: '#taxNumber',
  taxOffice: '@search-dropdown:invoice.Customer.TaxOffice',
  city: '@search-dropdown:invoice.Customer.Address.City',
  district: '@search-dropdown:invoice.Customer.Address.CitySubdivisionName',
  address: '#addressStreet',
  phone: '#customerPhone',
  email: '#customerEmail',
  lineName: '@css-index:{index}:#stockName',
  lineQuantity: '@css-index:{index}:#quantity',
  lineUnitPrice: '@css-index:{index}:#unitPrice',
  lineVatRate: '@css-index:{index}:#vatRateInput',
  lineSctRate: '@skip',
  lineDescription: '@skip',
  paymentNote: '@skip',
  generalNote: '#invoiceDescription',
}
const defaultPageMarkers = ['#invoiceDescription', '#stockName', '@text:Taslaklara kaydet']
let loadedProfile = null

const fields = {
  enabled: document.getElementById('enabled'),
  draftUrl: document.getElementById('draftUrl'),
  selectorVersion: document.getElementById('selectorVersion'),
  pageMarkers: document.getElementById('pageMarkers'),
  selectors: document.getElementById('selectors'),
}
const status = document.getElementById('status')

function show(message, error = false) {
  status.textContent = message
  status.classList.toggle('error', error)
}

async function load() {
  const stored = await chrome.storage.local.get(PROFILE_KEY)
  loadedProfile = (stored[PROFILE_KEY] || []).find((item) => item.key === 'mikrogroup_eportal') || null
  const profile = loadedProfile || {
    enabled: true,
    selectorVersion: BUILTIN_SELECTOR_VERSION,
    pageMarkers: defaultPageMarkers,
    selectors: defaultSelectors,
    customerStrategy: 'mikro-new-customer-v1',
    taxStrategy: 'mikro-semantic-tax-v1',
  }
  fields.enabled.checked = profile.enabled !== false
  fields.draftUrl.value = `${MIKRO_ORIGIN}/`
  fields.selectorVersion.value = profile.selectorVersion || BUILTIN_SELECTOR_VERSION
  fields.pageMarkers.value = (profile.pageMarkers?.length ? profile.pageMarkers : defaultPageMarkers).join('\n')
  fields.selectors.value = JSON.stringify({ ...defaultSelectors, ...(profile.selectors || {}) }, null, 2)
}

document.getElementById('form').addEventListener('submit', async (event) => {
  event.preventDefault()
  try {
    const selectors = JSON.parse(fields.selectors.value)
    if (!selectors || typeof selectors !== 'object' || Array.isArray(selectors)) throw new Error('Alan eşleştirme JSON’u bir nesne olmalıdır.')
    const forbidden = Object.keys(selectors).find((key) => forbiddenKey.test(key))
    if (forbidden) throw new Error(`Resmî işlem düğmesi seçicisi kabul edilmez: ${forbidden}`)
    const missing = requiredSelectorKeys.filter((key) => typeof selectors[key] !== 'string')
    if (missing.length) throw new Error(`Eksik seçici anahtarları: ${missing.join(', ')}`)
    const pageMarkers = fields.pageMarkers.value.split(/\r?\n/).map((value) => value.trim()).filter(Boolean)
    if (!pageMarkers.length) throw new Error('En az bir sayfa doğrulama işareti girin.')
    const selectorVersion = fields.selectorVersion.value.trim()
    if (!selectorVersion || selectorVersion === 'unverified') throw new Error('Doğrulanmış bir seçici sürümü girin.')
    const profile = {
      ...(loadedProfile || {}),
      key: 'mikrogroup_eportal',
      name: 'Mikrogroup ePortal',
      enabled: fields.enabled.checked,
      origin: MIKRO_ORIGIN,
      draftUrl: `${MIKRO_ORIGIN}/`,
      selectorVersion,
      pageMarkers,
      selectors,
      customerStrategy: loadedProfile?.customerStrategy || 'mikro-new-customer-v1',
      taxStrategy: loadedProfile?.taxStrategy || 'mikro-semantic-tax-v1',
    }
    const stored = await chrome.storage.local.get(PROFILE_KEY)
    const profiles = Array.isArray(stored[PROFILE_KEY]) ? stored[PROFILE_KEY] : []
    const next = profiles.some((item) => item.key === 'mikrogroup_eportal')
      ? profiles.map((item) => item.key === 'mikrogroup_eportal' ? profile : item)
      : [...profiles, profile]
    await chrome.storage.local.set({ [PROFILE_KEY]: next })
    loadedProfile = profile
    show('Mikro ePortal seçici profili kaydedildi.')
  } catch (error) {
    show(error.message || 'Profil kaydedilemedi.', true)
  }
})

load()
