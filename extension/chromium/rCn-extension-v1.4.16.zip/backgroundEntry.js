import './background.js'
import './gibBackground.js'

const RCN_WEB_BRIDGE_PATTERNS = Object.freeze([
  'https://rcn.net.tr/*',
  'https://*.rcn.net.tr/*',
  'https://rcnf.arcan.workers.dev/*',
])
const RCN_WEB_BRIDGE_FILES = Object.freeze([
  'webextCompat.js',
  'content/bridge.js',
  'content/gibWebBridge.js',
])

async function ensureRcnWebBridgeOnOpenTabs() {
  if (!chrome?.tabs?.query || !chrome?.scripting?.executeScript) return
  const tabs = await chrome.tabs.query({ url: RCN_WEB_BRIDGE_PATTERNS }).catch(() => [])
  for (const tab of tabs || []) {
    if (!Number.isInteger(tab?.id) || tab.id < 0) continue
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: RCN_WEB_BRIDGE_FILES,
    }).catch(() => {})
  }
}

chrome.runtime.onInstalled.addListener(() => { void ensureRcnWebBridgeOnOpenTabs() })
chrome.runtime.onStartup.addListener(() => { void ensureRcnWebBridgeOnOpenTabs() })
void ensureRcnWebBridgeOnOpenTabs()
