(() => {
  const text = (value) => String(value ?? '').trim()
  const money = (value) => (Math.round((Number(value) || 0) * 100) / 100).toFixed(2)
  const unitPriceValue = (line) => text(line?.taxType) === 'Konaklama V'
    ? (Math.round((Number(line?.unitPrice) || 0) * 1000) / 1000).toFixed(3)
    : money(line?.unitPrice)
  const normalize = (value) => text(value).replace(/\s+/g, ' ').toLocaleLowerCase('tr-TR')
  const SKIP = Symbol('skip')

  class MikroAdapterError extends Error {
    constructor(code, message) {
      super(message)
      this.name = 'MikroAdapterError'
      this.code = code
    }
  }

  function fail(code, message) {
    throw new MikroAdapterError(code, message)
  }

  function selectorAt(template, index) {
    return text(template).replaceAll('{index}', String(index + 1))
  }

  function queryAll(root, selector) {
    try { return Array.from(root?.querySelectorAll?.(selector) || []) } catch (_) { return [] }
  }

  function attribute(element, name) {
    try { return text(element?.getAttribute?.(name)) } catch (_) { return '' }
  }

  function elementText(element) {
    return text(element?.textContent || element?.innerText || element?.value || attribute(element, 'aria-label') || attribute(element, 'title') || attribute(element, 'placeholder'))
  }

  function alternatives(value) {
    return text(value).split('|').map((item) => normalize(item)).filter(Boolean)
  }

  function exactTextMatch(value, needles) {
    const normalized = normalize(value)
    return needles.includes(normalized)
  }

  function includesTextMatch(value, needles) {
    const normalized = normalize(value)
    return needles.some((needle) => normalized.includes(needle))
  }

  function findTextElement(root, rawAlternatives, exact = false) {
    const needles = alternatives(rawAlternatives)
    if (!needles.length) return null
    const nodes = queryAll(root, 'h1,h2,h3,h4,h5,label,span,p,button,a,li,[role="option"],[role="menuitem"],[role="dialog"],div')
      .filter((element) => (exact ? exactTextMatch(elementText(element), needles) : includesTextMatch(elementText(element), needles)))
      .sort((first, second) => elementText(first).length - elementText(second).length)
    return nodes[0] || null
  }

  function isControl(element) {
    const tag = text(element?.tagName).toUpperCase()
    return ['INPUT', 'TEXTAREA', 'SELECT'].includes(tag) || Boolean(element?.isContentEditable) || attribute(element, 'role') === 'combobox'
  }

  function controlCandidates(root) {
    return queryAll(root, 'input:not([type="hidden"]),textarea,select,[contenteditable="true"],[role="combobox"]')
  }

  function controlFromLabel(documentRef, label) {
    if (!label) return null
    const htmlFor = attribute(label, 'for') || text(label?.htmlFor)
    if (htmlFor && documentRef?.getElementById) {
      const direct = documentRef.getElementById(htmlFor)
      if (isControl(direct)) return direct
    }
    if (isControl(label)) return label
    const inside = controlCandidates(label)
    if (inside.length === 1) return inside[0]
    let current = label?.parentElement || null
    for (let depth = 0; current && depth < 5; depth += 1, current = current.parentElement) {
      const controls = controlCandidates(current)
      if (controls.length === 1) return controls[0]
      const next = current.nextElementSibling
      if (isControl(next)) return next
      if (next) {
        const nextControls = controlCandidates(next)
        if (nextControls.length === 1) return nextControls[0]
      }
    }
    return null
  }

  function parseLabelDirective(selector) {
    const optional = selector.startsWith('@optional-label:')
    const prefix = optional ? '@optional-label:' : '@label:'
    if (!selector.startsWith(prefix)) return null
    const body = selector.slice(prefix.length)
    const match = body.match(/^(\d+):(.*)$/)
    return {
      optional,
      index: match ? Math.max(Number(match[1]) || 1, 1) : 1,
      labels: match ? match[2] : body,
    }
  }

  function parseCssIndexDirective(selector) {
    const match = selector.match(/^@css-index:(\d+):(.*)$/)
    if (!match) return null
    return { index: Math.max(Number(match[1]) || 1, 1), selector: text(match[2]) }
  }

  function parseSearchDropdownDirective(selector) {
    if (!selector.startsWith('@search-dropdown:')) return null
    return text(selector.slice('@search-dropdown:'.length))
  }

  function findLabeledControl(documentRef, directive) {
    const needles = alternatives(directive.labels)
    const labels = queryAll(documentRef, 'label,span,p,div')
      .filter((element) => exactTextMatch(elementText(element), needles))
    const controls = []
    for (const label of labels) {
      const control = controlFromLabel(documentRef, label)
      if (control && !controls.includes(control)) controls.push(control)
    }
    return controls[directive.index - 1] || null
  }

  function findSearchDropdown(documentRef, selectedItem) {
    return queryAll(documentRef, 'search-dropdown').find((element) => attribute(element, 'selected-item') === selectedItem) || null
  }

  function resolveElement(documentRef, selector, label) {
    const normalizedSelector = text(selector)
    if (!normalizedSelector || normalizedSelector === '@skip') return SKIP
    if (normalizedSelector.startsWith('@text:')) {
      const element = findTextElement(documentRef, normalizedSelector.slice(6), false)
      if (!element) fail('ELEMENT_NOT_FOUND', `${label} hedef sayfada bulunamadı. Sayfa değişmiş olabilir; hiçbir veri yazılmadı.`)
      return element
    }
    const cssIndex = parseCssIndexDirective(normalizedSelector)
    if (cssIndex) {
      const element = queryAll(documentRef, cssIndex.selector)[cssIndex.index - 1] || null
      if (!element) fail('ELEMENT_NOT_FOUND', `${label} alanı hedef sayfada bulunamadı. Sayfa değişmiş olabilir; hiçbir veri yazılmadı.`)
      return element
    }
    const searchDropdown = parseSearchDropdownDirective(normalizedSelector)
    if (searchDropdown) {
      const component = findSearchDropdown(documentRef, searchDropdown)
      if (!component) fail('ELEMENT_NOT_FOUND', `${label} seçim alanı hedef sayfada bulunamadı. Sayfa değişmiş olabilir; hiçbir veri yazılmadı.`)
      return component
    }
    const directive = parseLabelDirective(normalizedSelector)
    if (directive) {
      const control = findLabeledControl(documentRef, directive)
      if (!control && directive.optional) return null
      if (!control) fail('ELEMENT_NOT_FOUND', `${label} alanı hedef sayfada bulunamadı. Sayfa değişmiş olabilir; hiçbir veri yazılmadı.`)
      return control
    }
    let element
    try { element = documentRef.querySelector(normalizedSelector) } catch (_) { fail('SELECTOR_INVALID', `${label} seçicisi geçerli değil.`) }
    if (!element) fail('ELEMENT_NOT_FOUND', `${label} alanı hedef sayfada bulunamadı. Sayfa değişmiş olabilir; hiçbir veri yazılmadı.`)
    return element
  }

  function requireElement(documentRef, selector, label) {
    if (!selector) fail('SELECTOR_MISSING', `${label} seçicisi tanımlı değil.`)
    return resolveElement(documentRef, selector, label)
  }

  function assertProfile(documentRef, profile) {
    if (!profile || profile.enabled !== true) fail('PROFILE_DISABLED', 'Mikro ePortal entegrasyon profili etkin değil.')
    if (profile.origin !== window.location.origin) fail('ORIGIN_MISMATCH', 'Açık sayfa doğrulanmış Mikro ePortal alan adıyla uyuşmuyor.')
    if (!text(profile.selectorVersion) || profile.selectorVersion === 'unverified') fail('SELECTOR_VERSION_UNVERIFIED', 'Mikro ePortal seçici profili henüz doğrulanmadı.')
    const markers = Array.isArray(profile.pageMarkers) ? profile.pageMarkers.filter(text) : []
    if (!markers.length) fail('PAGE_MARKER_REQUIRED', 'Sayfa doğrulama işaretleri tanımlı değil.')
    markers.forEach((selector, index) => {
      const marker = requireElement(documentRef, selector, `${index + 1}. sayfa doğrulama işareti`)
      if (marker === SKIP) fail('PAGE_MARKER_INVALID', 'Sayfa doğrulama işareti atlanamaz.')
    })
  }

  function serialNote(line) {
    if (text(line?.description)) return text(line.description)
    const vehicle = [
      text(line?.name),
      line?.chassisNo ? `Şasi no : ${text(line.chassisNo)}` : '',
      line?.engineNo ? `Motor no: ${text(line.engineNo)}` : '',
      line?.variant ? `Varyant: ${text(line.variant)}` : '',
    ].filter(Boolean).join(' ')
    return [vehicle, line?.maintenanceNote ? `(${text(line.maintenanceNote)})` : ''].filter(Boolean).join('\n')
  }

  function splitRecipientName(recipient) {
    const directFirst = text(recipient?.firstName)
    const directLast = text(recipient?.lastName)
    if (directFirst || directLast) return { firstName: directFirst, lastName: directLast }
    const parts = text(recipient?.title).split(/\s+/).filter(Boolean)
    if (parts.length <= 1) return { firstName: parts[0] || '', lastName: '' }
    return { firstName: parts.slice(0, -1).join(' '), lastName: parts.at(-1) }
  }

  function setPlanField(plan, documentRef, selector, value, label, meta = {}) {
    if (value === null || value === undefined || value === '') return null
    const element = requireElement(documentRef, selector, label)
    if (element === SKIP || element === null) return element
    const kind = parseSearchDropdownDirective(text(selector)) ? 'choice' : 'field'
    const item = { kind, element, selector, value: String(value), label, ...meta }
    plan.push(item)
    return item
  }

  function findRowContainer(element) {
    if (!element) return null
    const closest = element.closest?.('tr,[role="row"],[class*="invoice-item"],[class*="product-row"],[class*="line-row"],[class*="item-row"]')
    if (closest) return closest
    let current = element.parentElement
    for (let depth = 0; current && depth < 6; depth += 1, current = current.parentElement) {
      const controls = controlCandidates(current)
      const buttons = queryAll(current, 'button,[role="button"]')
      if (controls.length >= 2 && buttons.length) return current
    }
    return element.parentElement || null
  }

  function menuButtonScore(button) {
    const searchable = normalize([elementText(button), attribute(button, 'aria-label'), attribute(button, 'title'), text(button?.innerHTML)].join(' '))
    if (/vergi|muafiyet/.test(searchable)) return -100
    if (/işlem|islem|menü|menu|daha|more|ellipsis|kebab|three.?dot|more_vert|more_horiz/.test(searchable)) return 10
    if (/⋮|\.\.\./.test(elementText(button))) return 9
    if (!elementText(button) && queryAll(button, 'svg,i').length) return 3
    return 0
  }

  function findRowMenu(row) {
    const buttons = queryAll(row, 'button,[role="button"]').map((button) => ({ button, score: menuButtonScore(button) })).filter((item) => item.score > 0)
    buttons.sort((first, second) => second.score - first.score)
    if (!buttons.length) return null
    if (buttons.length > 1 && buttons[0].score === buttons[1].score && buttons[0].score <= 3) return null
    return buttons[0].button
  }

  function buildPlan(documentRef, job, profile) {
    assertProfile(documentRef, profile)
    const invoice = job?.invoice
    if (!invoice || invoice.operation !== 'create_invoice_draft') fail('UNSAFE_OPERATION', 'Yalnız fatura taslağı hazırlama işlemi desteklenir.')
    const selectors = profile.selectors || {}
    const plan = []
    const commercial = invoice.scenario?.key === 'commercial'

    setPlanField(plan, documentRef, selectors.documentType, invoice.document?.type, 'Belge türü', { key: 'documentType' })
    setPlanField(plan, documentRef, selectors.scenario, invoice.scenario?.adapterValue, 'Fatura senaryosu', { key: 'scenario' })
    setPlanField(plan, documentRef, commercial ? selectors.taxNo : selectors.identityNo, commercial ? invoice.recipient?.taxNo : invoice.recipient?.identityNo, commercial ? 'VKN' : 'TCKN', { key: commercial ? 'taxNo' : 'identityNo' })
    if (commercial) {
      setPlanField(plan, documentRef, selectors.recipientTitle, invoice.recipient?.title, 'Ünvan', { key: 'recipientTitle' })
      setPlanField(plan, documentRef, selectors.taxOffice, invoice.recipient?.taxOffice, 'Vergi dairesi', { key: 'taxOffice' })
    } else {
      const recipientName = splitRecipientName(invoice.recipient)
      setPlanField(plan, documentRef, selectors.recipientFirstName || selectors.recipientTitle, recipientName.firstName, 'Ad', { key: 'recipientFirstName' })
      setPlanField(plan, documentRef, selectors.recipientLastName, recipientName.lastName, 'Soyad', { key: 'recipientLastName' })
    }
    setPlanField(plan, documentRef, selectors.city, invoice.recipient?.city, 'İl', { key: 'city' })
    setPlanField(plan, documentRef, selectors.district, invoice.recipient?.district, 'İlçe', { key: 'district' })
    setPlanField(plan, documentRef, selectors.address, invoice.recipient?.address, 'Adres', { key: 'address' })
    setPlanField(plan, documentRef, selectors.phone, invoice.recipient?.phone, 'Telefon', { key: 'phone' })
    setPlanField(plan, documentRef, selectors.email, invoice.recipient?.email, 'E-posta', { key: 'email' })

    invoice.lines.forEach((line, index) => {
      const prefix = `${index + 1}. kalem`
      const lineName = setPlanField(plan, documentRef, selectorAt(selectors.lineName, index), line.name, `${prefix} ürün adı`, { key: 'lineName', lineIndex: index })
      setPlanField(plan, documentRef, selectorAt(selectors.lineQuantity, index), line.quantity, `${prefix} miktar`, { key: 'lineQuantity', lineIndex: index })
      setPlanField(plan, documentRef, selectorAt(selectors.lineUnitPrice, index), unitPriceValue(line), `${prefix} birim fiyat`, { key: 'lineUnitPrice', lineIndex: index })
      if (Number(line.vatRate) > 0) setPlanField(plan, documentRef, selectorAt(selectors.lineVatRate, index), line.vatRate, `${prefix} KDV oranı`, { key: 'lineVatRate', lineIndex: index })

      const sctRate = Number(line.sctRate)
      if (sctRate > 0 && profile.taxStrategy === 'mikro-semantic-tax-v1') {
        const row = findRowContainer(lineName?.element)
        const menu = findRowMenu(row)
        if (!row || !menu) fail('TAX_MENU_NOT_FOUND', `${prefix} için Vergi/Muafiyet menüsü doğrulanamadı. Hiçbir veri yazılmadı.`)
        plan.push({ kind: 'tax', row, menu, lineIndex: index, sctRate, label: `${prefix} ÖTV` })
      } else if (sctRate > 0) {
        const sctField = setPlanField(plan, documentRef, selectorAt(selectors.lineSctRate, index), sctRate, `${prefix} ÖTV oranı`, { key: 'lineSctRate', lineIndex: index })
        if (!sctField || sctField === SKIP) fail('SCT_FIELD_NOT_FOUND', `${prefix} için ÖTV oranı alanı doğrulanamadı. Hiçbir veri yazılmadı.`)
      }

      const taxType = text(line.taxType)
      if (taxType) {
        if (taxType !== 'Konaklama V') fail('UNSUPPORTED_TAX_TYPE', `${prefix} için desteklenmeyen vergi türü algılandı. Hiçbir veri yazılmadı.`)
        if (profile.taxStrategy !== 'mikro-semantic-tax-v1') fail('TAX_PROFILE_REQUIRED', `${prefix} için Konaklama V vergi profili doğrulanamadı. Hiçbir veri yazılmadı.`)
        const row = findRowContainer(lineName?.element)
        const menu = findRowMenu(row)
        if (!row || !menu) fail('TAX_MENU_NOT_FOUND', `${prefix} için Vergi/Muafiyet menüsü doğrulanamadı. Hiçbir veri yazılmadı.`)
        plan.push({ kind: 'accommodation-tax', row, menu, lineIndex: index, taxType, label: `${prefix} Konaklama V` })
      }

      setPlanField(plan, documentRef, selectorAt(selectors.lineDescription, index), serialNote(line), `${prefix} şasi/motor bilgisi`, { key: 'lineDescription', lineIndex: index })
    })

    const allSerials = invoice.lines.map(serialNote).filter(Boolean).join('\n')
    setPlanField(plan, documentRef, selectors.paymentNote, invoice.payment?.label, 'Ödeme açıklaması', { key: 'paymentNote' })
    setPlanField(plan, documentRef, selectors.generalNote, [invoice.note, allSerials].filter(Boolean).join('\n'), 'Belge notu', { key: 'generalNote' })
    return plan
  }

  function dispatchActivation(element) {
    if (!element) return
    const EventCtor = globalThis.MouseEvent || globalThis.Event
    element.dispatchEvent(new EventCtor('click', { bubbles: true, cancelable: true }))
  }

  function setNativeSelect(element, value, textValue = value) {
    const options = Array.from(element?.options || [])
    const needle = normalize(textValue)
    const option = options.find((item) => normalize(item.textContent || item.label) === needle || normalize(item.textContent || item.label).includes(needle))
    if (option) element.value = option.value
    else element.value = value
  }

  function writeValue(element, value) {
    const tagName = String(element.tagName || '').toUpperCase()
    if (tagName === 'SELECT') {
      element.focus?.()
      setNativeSelect(element, value)
    } else if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
      element.focus?.()
      element.value = value
    } else if (element.isContentEditable) {
      element.textContent = value
    } else if (attribute(element, 'role') === 'combobox') {
      element.focus?.()
      if ('value' in element) element.value = value
      else element.textContent = value
    } else {
      fail('UNSUPPORTED_ELEMENT', 'Hedef alan güvenli biçimde doldurulabilecek bir form alanı değil.')
    }
    for (const eventName of ['input', 'change', 'blur']) element.dispatchEvent(new Event(eventName, { bubbles: true }))
  }

  function waitFor(check, timeoutMs = 5000, intervalMs = 60) {
    const started = Date.now()
    return new Promise((resolve, reject) => {
      const run = () => {
        try {
          const value = check()
          if (value) return resolve(value)
        } catch (_) { /* retry until timeout */ }
        if (Date.now() - started >= timeoutMs) return reject(new MikroAdapterError('DOM_TIMEOUT', 'Mikro ePortal ekranı beklenen alanı zamanında göstermedi. İşlem durduruldu.'))
        setTimeout(run, intervalMs)
      }
      run()
    })
  }

  async function prepareTargetPage(documentRef, job, profile) {
    assertProfile(documentRef, profile)
    if (documentRef.querySelector('#taxNumber')) return { customerFormOpened: false }
    if (profile.customerStrategy !== 'mikro-new-customer-v1') return { customerFormOpened: false }
    const invoice = job?.invoice
    const identifier = invoice?.scenario?.key === 'commercial' ? invoice?.recipient?.taxNo : invoice?.recipient?.identityNo
    const search = documentRef.querySelector('#vknOrTitle')
    const trigger = documentRef.querySelector('.continue-new-customer')
      || findTextElement(documentRef, 'Yeni alıcı olarak fatura oluşturmak için tıklayınız', false)
    if (!trigger) fail('CUSTOMER_FORM_TRIGGER_NOT_FOUND', 'Mikro ePortal yeni alıcı formu açılamadı. Sayfa yapısı değişmiş olabilir.')
    if (search && identifier) writeValue(search, String(identifier))
    dispatchActivation(trigger)
    await waitFor(() => documentRef.querySelector('#taxNumber'))
    const autoSave = documentRef.querySelector('#cashAccountSaveAuto')
    if (autoSave?.checked) {
      autoSave.checked = false
      for (const eventName of ['input', 'change']) autoSave.dispatchEvent(new Event(eventName, { bubbles: true }))
    }
    return { customerFormOpened: true }
  }

  async function applyChoiceAction(action) {
    const component = action.element
    const current = queryAll(component, 'input[readonly]')[0]
    if (current && normalize(current.value) === normalize(action.value)) return
    const toggle = component.querySelector?.('[data-toggle="dropdown"]') || current
    if (!toggle) fail('CHOICE_CONTROL_NOT_FOUND', `${action.label} seçim alanı açılamadı.`)
    dispatchActivation(toggle)
    const option = await waitFor(() => queryAll(component, '.customer-list__item')
      .find((item) => exactTextMatch(elementText(item), [normalize(action.value)])))
    dispatchActivation(option)
  }

  function closestDialog(element) {
    return element?.closest?.('[role="dialog"],.modal,.fds-modal,[class*="modal"]') || null
  }

  function findButtonByText(root, value) {
    const needle = normalize(value)
    return queryAll(root, 'button,[role="button"],a,li,[role="menuitem"]').find((element) => normalize(elementText(element)) === needle) || null
  }

  function findTaxRateControl(dialog) {
    const labels = ['ÖTV Oranı', 'Vergi Oranı', 'Oran']
    for (const label of labels) {
      const control = findLabeledControl(dialog, { index: 1, labels: label })
      if (control) return control
    }
    const inputs = controlCandidates(dialog).filter((element) => String(element.tagName || '').toUpperCase() === 'INPUT' && attribute(element, 'type') !== 'hidden')
    return inputs.length === 1 ? inputs[0] : null
  }

  async function chooseTaxType(dialog, value) {
    const taxType = findLabeledControl(dialog, { index: 1, labels: 'Vergi Türü' })
    if (!taxType) fail('TAX_TYPE_NOT_FOUND', 'Vergi Türü alanı bulunamadı. ÖTV eklenmedi.')
    if (String(taxType.tagName || '').toUpperCase() === 'SELECT') {
      setNativeSelect(taxType, value, value)
      for (const eventName of ['input', 'change']) taxType.dispatchEvent(new Event(eventName, { bubbles: true }))
      return
    }
    dispatchActivation(taxType)
    const option = await waitFor(() => findTextElement(document, value, true))
    dispatchActivation(option)
  }

  async function applyTaxAction(action) {
    dispatchActivation(action.menu)
    const menuItem = await waitFor(() => findButtonByText(document, 'Vergi/Muafiyet'))
    dispatchActivation(menuItem)
    const modalTitle = await waitFor(() => findTextElement(document, 'Vergi/Muafiyet Bilgileri', false))
    const dialog = closestDialog(modalTitle) || modalTitle.parentElement || document
    const existing = findTextElement(dialog, 'ÖTV 2.LİSTE', true)
    if (!existing) {
      await chooseTaxType(dialog, 'ÖTV 2.LİSTE')
      const addTax = await waitFor(() => findButtonByText(dialog, 'Vergi Ekle'))
      dispatchActivation(addTax)
    }
    const rateControl = await waitFor(() => findTaxRateControl(dialog))
    writeValue(rateControl, String(action.sctRate))
    const confirm = await waitFor(() => findButtonByText(dialog, 'Tamam'))
    dispatchActivation(confirm)
  }

  async function applyAccommodationTaxAction(action) {
    dispatchActivation(action.menu)
    const menuItem = await waitFor(() => findButtonByText(document, 'Vergi/Muafiyet'))
    dispatchActivation(menuItem)
    const modalTitle = await waitFor(() => findTextElement(document, 'Vergi/Muafiyet Bilgileri', false))
    const dialog = closestDialog(modalTitle) || modalTitle.parentElement || document
    const existing = findTextElement(dialog, action.taxType, true)
    if (!existing) {
      await chooseTaxType(dialog, action.taxType)
      const addTax = await waitFor(() => findButtonByText(dialog, 'Vergi Ekle'))
      dispatchActivation(addTax)
      await waitFor(() => findTextElement(dialog, action.taxType, true))
    }
    const confirm = await waitFor(() => findButtonByText(dialog, 'Tamam'))
    dispatchActivation(confirm)
  }

  async function applyPlan(plan) {
    if (!Array.isArray(plan) || !plan.length) fail('EMPTY_PLAN', 'Doldurulacak alan bulunamadı.')
    const choices = plan.filter((item) => item.kind === 'choice')
    const fields = plan.filter((item) => item.kind === 'field')
    const taxActions = plan.filter((item) => item.kind === 'tax')
    const accommodationTaxActions = plan.filter((item) => item.kind === 'accommodation-tax')
    for (const action of choices) await applyChoiceAction(action)
    for (const { element, value } of fields) writeValue(element, value)
    for (const action of taxActions) await applyTaxAction(action)
    for (const action of accommodationTaxActions) await applyAccommodationTaxAction(action)
    return { writtenFieldCount: fields.length + choices.length, taxActionCount: taxActions.length + accommodationTaxActions.length }
  }

  function parseDisplayedMoney(value) {
    let source = text(value).replace(/₺|\bTL\b/gi, '').replace(/\s+/g, '')
    if (!source) return NaN
    const comma = source.lastIndexOf(',')
    const dot = source.lastIndexOf('.')
    if (comma >= 0) source = source.replace(/\./g, '').replace(',', '.')
    else if (dot >= 0 && source.length - dot - 1 === 3) source = source.replace(/\./g, '')
    source = source.replace(/[^0-9.-]/g, '')
    return Number(source)
  }

  function payableCandidates(documentRef) {
    const label = findTextElement(documentRef, 'Ödenecek Tutar', false)
    if (!label) return []
    const results = []
    let current = label.parentElement || label
    for (let depth = 0; current && depth < 6; depth += 1, current = current.parentElement) {
      const values = [current, ...queryAll(current, 'input,output,strong,b,span,p,div,td')]
      for (const element of values) {
        const source = text(element?.value || elementText(element))
        const matches = source.match(/-?\d[\d\s.,]*\d|-?\d/g) || []
        for (const match of matches) {
          const amount = parseDisplayedMoney(match)
          if (Number.isFinite(amount) && !results.includes(amount)) results.push(amount)
        }
      }
    }
    return results
  }

  function assertHotelFormReady(documentRef, job, profile) {
    if (job?.localHotelBatch !== true) return
    const selectors = profile?.selectors || {}
    const controls = [
      resolveElement(documentRef, selectors.recipientFirstName, 'Ad'),
      resolveElement(documentRef, selectors.recipientLastName, 'Soyad'),
      resolveElement(documentRef, selectorAt(selectors.lineName, 0), 'Hizmet adı'),
    ].filter((element) => element && element !== SKIP)
    if (controls.some((element) => text(element.value || element.textContent))) {
      fail('HOTEL_FORM_NOT_EMPTY', 'Mikro ePortal formu boş değil. Yeni fatura ekranını açıp “Sıradakini Doldur” işlemini yeniden başlatın.')
    }
  }

  async function validatePayableTotal(documentRef, expectedValue) {
    const expected = Math.round(Number(expectedValue) * 100) / 100
    if (!Number.isFinite(expected) || expected <= 0) fail('PAYABLE_TOTAL_INVALID', 'Beklenen ödenecek tutar geçersiz.')
    let latest = []
    try {
      await waitFor(() => {
        latest = payableCandidates(documentRef)
        return latest.some((amount) => Math.abs(amount - expected) <= 0.01)
      }, 7000, 100)
    } catch (_) {
      const observed = latest.length ? latest.map((amount) => money(amount)).join(', ') : 'okunamadı'
      fail('PAYABLE_TOTAL_MISMATCH', `Ödenecek tutar Excel ile eşleşmedi. Beklenen ${money(expected)}, ekranda ${observed}. Kişi tamamlanmış sayılmadı.`)
    }
    return { expected, verified: true }
  }

  globalThis.RcnMikroAdapter = {
    MikroAdapterError,
    prepareTargetPage,
    buildPlan,
    applyPlan,
    serialNote,
    assertHotelFormReady,
    validatePayableTotal,
  }
})()
