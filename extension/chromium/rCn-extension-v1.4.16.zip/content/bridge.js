(() => {
  if (globalThis.__RCN_EXTENSION_BRIDGE_V2__) return
  globalThis.__RCN_EXTENSION_BRIDGE_V2__ = true

  const CHANNEL = 'rcn-extension-v2'
  const MESSAGE_TYPE = 'RCN_INTEGRATION_JOB_READY'
  const forwardedJobs = new Set()

  function isAllowedRcnOrigin(value) {
    try {
      const url = new URL(String(value || ''))
      if (url.protocol !== 'https:') return false
      const hostname = url.hostname.toLocaleLowerCase('en-US')
      return hostname === 'rcn.net.tr' || hostname.endsWith('.rcn.net.tr') || url.origin === 'https://rcnf.arcan.workers.dev'
    } catch (_) {
      return false
    }
  }

  if (!isAllowedRcnOrigin(window.location.origin)) return

  const emit = (name, detail) => window.dispatchEvent(new CustomEvent(name, { detail }))
  const announceBridge = (nonce = '') => emit('rcn:extension-bridge-ready', { channel: CHANNEL, origin: window.location.origin, nonce: String(nonce || '') })
  const emitError = (operation, error, context = {}) => emit('rcn:extension-error', {
    operation,
    message: error?.message || 'rCn eklenti işlemi tamamlanamadı.',
    ...context,
  })

  window.addEventListener('rcn:extension-bridge-state-request', (event) => {
    announceBridge(event.detail?.nonce || '')
  })

  window.addEventListener('rcn:integration-job-ready', (event) => {
    const payload = event.detail
    if (!payload || payload.source !== 'rcn-app' || payload.channel !== CHANNEL || payload.type !== MESSAGE_TYPE) return
    const jobId = payload.job?.jobId
    const operationKey = payload.job?.operationKey
    if (typeof jobId !== 'string' || forwardedJobs.has(jobId)) return
    forwardedJobs.add(jobId)
    chrome.runtime.sendMessage({ type: 'RCN_CAPTURE_JOB', payload })
      .then((response) => {
        if (!response?.ok) throw new Error(response?.error || 'Eklenti işi alınamadı.')
        emit('rcn:extension-job-captured', response.result)
      })
      .catch((error) => {
        forwardedJobs.delete(jobId)
        emitError('capture_job', error, { jobId, operationKey })
      })
  })

  window.addEventListener('rcn:extension-pairing-request', (event) => {
    chrome.runtime.sendMessage({ type: 'RCN_CLAIM_PAIRING', payload: event.detail })
      .then((response) => {
        if (!response?.ok) throw new Error(response?.error || 'Eklenti eşleştirme isteğini alamadı.')
        emit('rcn:extension-pairing-claimed', response.result)
      })
      .catch((error) => emitError('claim_pairing', error))
  })

  window.addEventListener('rcn:extension-pairing-approved', (event) => {
    chrome.runtime.sendMessage({ type: 'RCN_ACCEPT_PAIRING', payload: event.detail })
      .then((response) => {
        if (!response?.ok) throw new Error(response?.error || 'Eklenti cihaz oturumu alınamadı.')
        emit('rcn:extension-session-updated', response.result)
      })
      .catch((error) => emitError('accept_pairing', error))
  })

  announceBridge()
})()
