(() => {
  const adapter = globalThis.RcnMikroAdapter
  if (!adapter || adapter.__taxPatch136) return

  const baseApplyPlan = adapter.applyPlan.bind(adapter)
  const canonical = (value) => String(value ?? '')
    .trim()
    .toLocaleLowerCase('tr-TR')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9çğıöşü]+/gi, '')
  const text = (element) => String(element?.textContent || element?.innerText || element?.value || '').trim()
  const attr = (element, name) => String(element?.getAttribute?.(name) || '').trim()
  const queryAll = (root, selector) => {
    try { return Array.from(root?.querySelectorAll?.(selector) || []) } catch (_) { return [] }
  }
  const visible = (element) => {
    if (!element) return false
    const style = globalThis.getComputedStyle?.(element)
    return style ? style.display !== 'none' && style.visibility !== 'hidden' : true
  }
  const dispatch = (element, type) => {
    if (!element) return
    const EventCtor = type === 'click' ? (globalThis.MouseEvent || globalThis.Event) : globalThis.Event
    element.dispatchEvent(new EventCtor(type, { bubbles: true, cancelable: true }))
  }
  const waitFor = (check, timeoutMs = 5000, intervalMs = 60) => new Promise((resolve, reject) => {
    const startedAt = Date.now()
    const run = () => {
      try {
        const value = check()
        if (value) return resolve(value)
      } catch (_) { /* retry */ }
      if (Date.now() - startedAt >= timeoutMs) return reject(new Error('Mikro ePortal beklenen vergi alanını zamanında göstermedi. İşlem durduruldu.'))
      setTimeout(run, intervalMs)
    }
    run()
  })

  const TAX_LABEL = 'ÖTV 2. Liste'
  const TAX_KEY = canonical(TAX_LABEL)

  function taxLabel(action) {
    return action?.kind === 'accommodation-tax' ? String(action.taxType || 'Konaklama V') : TAX_LABEL
  }

  function findByCanonicalText(root, value) {
    const expected = canonical(value)
    return queryAll(root, 'label,span,p,div,button,li,a,[role="option"],[role="menuitem"],option')
      .filter((element) => canonical(text(element)) === expected)
      .sort((first, second) => text(first).length - text(second).length)[0] || null
  }

  function closestDialog(element) {
    if (!element) return null
    return element.closest?.('[role="dialog"]')
      || element.closest?.('.modal.show')
      || element.closest?.('.modal')
      || null
  }

  function optionMatching(select, label = TAX_LABEL) {
    const expected = canonical(label)
    return Array.from(select?.options || []).find((option) => canonical(option?.textContent || option?.label) === expected) || null
  }

  function selectContainingTarget(dialog, label) {
    const allSelects = queryAll(dialog, 'select')
    return allSelects.find((select) => !select.disabled && optionMatching(select, label)) || null
  }

  function controlCandidates(root) {
    return queryAll(root, [
      'select',
      '[role="combobox"]',
      'search-dropdown',
      'input[readonly][data-toggle="dropdown"]',
      'input[aria-haspopup="listbox"]',
      'button[aria-haspopup="listbox"]',
      '[data-toggle="dropdown"]',
      '.dropdown-toggle',
      '.select2-selection',
      'ng-select',
    ].join(','))
      .filter((element) => visible(element) && !element.disabled)
  }

  function semanticHint(element) {
    if (!element) return ''
    const names = ['ng-model', 'data-ng-model', 'name', 'id', 'aria-label', 'placeholder', 'data-placeholder', 'title', 'class']
    const own = names.map((name) => attr(element, name)).filter(Boolean).join(' ')
    const nested = queryAll(element, 'input,button,select,[role="combobox"]')
      .slice(0, 12)
      .flatMap((child) => names.map((name) => attr(child, name)).filter(Boolean))
      .join(' ')
    return canonical(`${own} ${nested}`)
  }

  function looksLikeTaxTypeControl(element) {
    const hint = semanticHint(element)
    return hint.includes('selectedtax') || hint.includes('taxtype') || hint.includes('vergituru') || hint.includes('vergituruseciniz')
  }

  function looksLikeExemptionControl(element) {
    const hint = semanticHint(element)
    return hint.includes('istisna') || hint.includes('muafiyet') || hint.includes('exemption')
  }

  function uniqueElements(items) {
    const result = []
    for (const item of items || []) if (item && !result.includes(item)) result.push(item)
    return result
  }

  function resolveToggle(control) {
    if (!control) return null
    const nested = control?.querySelector?.([
      '[role="combobox"]',
      '[aria-haspopup="listbox"]',
      '[aria-haspopup="menu"]',
      '[data-toggle="dropdown"]',
      'input[readonly]',
      'button[aria-haspopup]',
      'button[data-toggle="dropdown"]',
      'button.dropdown-toggle',
      '.dropdown-toggle',
      '.select2-selection',
      '.ng-select-container',
    ].join(','))
    if (nested && visible(nested) && !nested.disabled) return nested
    if (control?.matches?.([
      'input',
      'button',
      '[role="combobox"]',
      '[aria-haspopup]',
      '[data-toggle="dropdown"]',
      'search-dropdown',
      'ng-select',
      '.dropdown-toggle',
      '.select2-selection',
      '.ng-select-container',
    ].join(',')) && visible(control) && !control.disabled) return control
    return null
  }

  function probeCandidates(dialog) {
    const direct = controlCandidates(dialog)
    const wrappers = queryAll(dialog, [
      '[class*="dropdown"]',
      '[class*="select"]',
      '[class*="combobox"]',
      '.form-group',
      '.form-control',
    ].join(',')).filter((element) => visible(element))
    return uniqueElements([...direct, ...wrappers])
      .filter((element) => !looksLikeExemptionControl(element))
      .map((element) => ({ control: element, toggle: resolveToggle(element) }))
      .filter((item) => item.toggle)
      .filter((item, index, items) => items.findIndex((other) => other.toggle === item.toggle) === index)
  }

  function findVisibleTargetOption(label, dialog = document) {
    const expected = canonical(label)
    const selectors = [
      'li',
      'a',
      'button',
      '[role="option"]',
      '[role="menuitem"]',
      '.customer-list__item',
      '.dropdown-item',
      '.select2-results__option',
      '.ng-option',
      'option',
    ].join(',')
    for (const scope of uniqueElements([dialog, document])) {
      const match = queryAll(scope, selectors)
        .filter(visible)
        .find((item) => canonical(text(item)) === expected)
      if (match) return match
    }
    return null
  }

  function waitForOptional(check, timeoutMs = 900, intervalMs = 60) {
    return new Promise((resolve) => {
      const startedAt = Date.now()
      const run = () => {
        try {
          const value = check()
          if (value) return resolve(value)
        } catch (_) { /* continue */ }
        if (Date.now() - startedAt >= timeoutMs) return resolve(null)
        setTimeout(run, intervalMs)
      }
      run()
    })
  }

  function closeProbeDropdown(toggle) {
    try {
      const KeyboardCtor = globalThis.KeyboardEvent || globalThis.Event
      document.dispatchEvent(new KeyboardCtor('keydown', { key: 'Escape', code: 'Escape', bubbles: true, cancelable: true }))
      document.dispatchEvent(new KeyboardCtor('keyup', { key: 'Escape', code: 'Escape', bubbles: true, cancelable: true }))
    } catch (_) { /* best effort */ }
    if (attr(toggle, 'aria-expanded') === 'true') dispatch(toggle, 'click')
  }

  async function searchTargetInToggle(toggle, dialog, label) {
    if (String(toggle?.tagName || '').toUpperCase() !== 'INPUT' || toggle.readOnly) return null
    const originalValue = String(toggle.value || '')
    toggle.focus?.()
    toggle.value = label
    for (const eventName of ['input', 'change', 'keyup']) dispatch(toggle, eventName)
    const option = await waitForOptional(() => findVisibleTargetOption(label, dialog), 1200)
    if (option) return option
    toggle.value = originalValue
    for (const eventName of ['input', 'change', 'keyup']) dispatch(toggle, eventName)
    return null
  }

  async function probeTaxTypeControl(dialog, label) {
    const candidates = probeCandidates(dialog)
    for (const item of candidates) {
      if (String(item.control?.tagName || '').toUpperCase() === 'SELECT') {
        try {
          await chooseNativeSelect(item.control, label)
          return { selected: true, candidateCount: candidates.length }
        } catch (_) {
          continue
        }
      }

      dispatch(item.toggle, 'click')
      let option = await waitForOptional(() => findVisibleTargetOption(label, dialog))
      if (!option) option = await searchTargetInToggle(item.toggle, dialog, label)
      if (option) {
        dispatch(option, 'click')
        return { selected: true, candidateCount: candidates.length }
      }
      closeProbeDropdown(item.toggle)
    }
    return { selected: false, candidateCount: candidates.length }
  }

  function controlsNearLabel(label) {
    if (!label) return []
    const result = []
    const push = (items) => {
      for (const item of items) if (item && !result.includes(item)) result.push(item)
    }
    const htmlFor = attr(label, 'for') || String(label?.htmlFor || '').trim()
    if (htmlFor) push([document.getElementById?.(htmlFor)])
    let current = label.parentElement
    for (let depth = 0; current && depth < 6; depth += 1, current = current.parentElement) {
      push(controlCandidates(current))
      if (current.nextElementSibling) push(controlCandidates(current.nextElementSibling))
    }
    return result.filter(Boolean)
  }

  function findTaxTypeControl(dialog, taxName) {
    const exactTaxType = dialog?.querySelector?.('select#taxType')
      || (document.querySelector?.('[role="dialog"] select#taxType') || null)
    if (exactTaxType && !exactTaxType.disabled) return exactTaxType

    const byTargetOption = selectContainingTarget(dialog, taxName)
    if (byTargetOption) return byTargetOption

    const candidates = controlCandidates(dialog)
    const semanticMatches = candidates.filter(looksLikeTaxTypeControl)
    if (semanticMatches.length === 1) return semanticMatches[0]
    if (semanticMatches.length > 1) {
      const withoutExemption = semanticMatches.filter((element) => !looksLikeExemptionControl(element))
      if (withoutExemption.length === 1) return withoutExemption[0]
    }

    const typeLabel = queryAll(dialog, 'label,span,p,div')
      .find((element) => {
        const value = canonical(text(element))
        return value === canonical('Vergi Türü') || value === canonical('Vergi Türü Seçiniz')
      })
    const nearby = controlsNearLabel(typeLabel).filter((element) => !looksLikeExemptionControl(element))
    if (nearby.length === 1) return nearby[0]

    const nonExemption = candidates.filter((element) => !looksLikeExemptionControl(element))
    if (candidates.length === 2 && nonExemption.length === 1) return nonExemption[0]

    const nativeSelects = queryAll(dialog, 'select').filter((element) => visible(element) && !element.disabled)
    const targetNative = nativeSelects.filter((element) => !looksLikeExemptionControl(element))
    if (targetNative.length === 1 && (typeLabel || nativeSelects.length === 1)) return targetNative[0]
    return null
  }

  function selectedOptionLabel(select) {
    const option = select?.options?.[select.selectedIndex]
    return String(option?.textContent || option?.label || '').trim()
  }

  async function chooseNativeSelect(select, label) {
    if (!select) throw new Error('Mikro ePortal Vergi Türü select alanı bulunamadı.')
    select.focus?.()
    dispatch(select, 'click')

    const option = await waitFor(() => optionMatching(select, label), 6000, 80)
    const optionIndex = Array.from(select.options || []).indexOf(option)

    try {
      const nativeSetter = Object.getOwnPropertyDescriptor(globalThis.HTMLSelectElement?.prototype || {}, 'value')?.set
      if (nativeSetter) nativeSetter.call(select, option.value)
      else select.value = option.value
    } catch (_) {
      select.value = option.value
    }

    if (optionIndex >= 0) select.selectedIndex = optionIndex
    option.selected = true

    for (const eventName of ['input', 'change', 'keyup', 'blur']) dispatch(select, eventName)
    await waitFor(() => canonical(selectedOptionLabel(select)) === canonical(label), 2000, 60)
  }

  async function chooseCustomControl(control, dialog, label) {
    const toggle = resolveToggle(control)
    if (!toggle) return false
    dispatch(toggle, 'click')
    let option = await waitForOptional(() => findVisibleTargetOption(label, dialog), 1200)
    if (!option) option = await searchTargetInToggle(toggle, dialog, label)
    if (!option) {
      closeProbeDropdown(toggle)
      return false
    }
    dispatch(option, 'click')
    return true
  }

  async function chooseTaxTypeInMainWorld(label) {
    const response = await chrome.runtime.sendMessage({ type: 'RCN_MIKRO_SELECT_TAX_MAIN', label })
    if (!response?.ok) throw new Error(response?.error || `${label} Mikro MAIN-world seçiminde doğrulanamadı.`)
    return response.result
  }

  async function chooseTaxType(dialog, label) {
    const exactTaxType = dialog?.querySelector?.('select#taxType') || document.querySelector?.('[role="dialog"] select#taxType') || document.querySelector?.('select#taxType')
    if (exactTaxType) {
      await chooseTaxTypeInMainWorld(label)
      return
    }

    const control = findTaxTypeControl(dialog, label)
    if (control) {
      if (String(control.tagName || '').toUpperCase() === 'SELECT') {
        try {
          await chooseNativeSelect(control, label)
          return
        } catch (_) {
          // Eski/farklı Mikro DOM varyantında fallback devam eder.
        }
      } else if (await chooseCustomControl(control, dialog, label)) {
        return
      }
    }

    const probed = await probeTaxTypeControl(dialog, label)
    if (probed.selected) return
    throw new Error(`Mikro ePortal Vergi Türü kontrolü hedef seçenekle doğrulanamadı. ${label} bulunamadı; ${probed.candidateCount} güvenli seçim adayı denendi ve işlem durduruldu.`)
  }

  function findRateControl(dialog) {
    const numericInputs = queryAll(dialog, 'input[type="number"],input[inputmode="decimal"],input[inputmode="numeric"]')
      .filter((element) => visible(element) && !element.disabled && !element.readOnly)
    const byModel = numericInputs.find((element) => /(^|\.)rate$|tax.*rate|rate.*tax/i.test(attr(element, 'ng-model')))
    if (byModel) return byModel

    const taxText = queryAll(dialog, 'label,span,p,div,td')
      .find((element) => canonical(text(element)) === TAX_KEY)
    if (taxText) {
      let current = taxText.parentElement
      for (let depth = 0; current && depth < 7; depth += 1, current = current.parentElement) {
        const controls = queryAll(current, 'input[type="number"],input[inputmode="decimal"],input[inputmode="numeric"]')
          .filter((element) => visible(element) && !element.disabled && !element.readOnly)
        if (controls.length === 1) return controls[0]
      }
    }
    return numericInputs.length === 1 ? numericInputs[0] : null
  }

  function writeNumber(element, value) {
    element.focus?.()
    element.value = String(value)
    for (const eventName of ['input', 'change', 'keyup', 'blur']) dispatch(element, eventName)
  }

  async function applyTaxAction(action) {
    const label = taxLabel(action)
    const taxKey = canonical(label)
    dispatch(action.menu, 'click')
    const menuItem = await waitFor(() => findByCanonicalText(document, 'Vergi/Muafiyet'))
    dispatch(menuItem, 'click')

    const title = await waitFor(() => findByCanonicalText(document, 'Vergi/Muafiyet Bilgileri'))
    const dialog = closestDialog(title) || title.parentElement || document
    let existingTax = queryAll(dialog, 'label,span,p,div,td')
      .find((element) => canonical(text(element)) === taxKey)

    if (!existingTax) {
      await chooseTaxType(dialog, label)
      const addTax = await waitFor(() => findByCanonicalText(dialog, 'Vergi Ekle'))
      dispatch(addTax, 'click')
      existingTax = await waitFor(() => queryAll(dialog, 'label,span,p,div,td')
        .find((element) => canonical(text(element)) === taxKey))
    }

    if (action.kind === 'tax') {
      const rateControl = await waitFor(() => findRateControl(dialog))
      writeNumber(rateControl, action.sctRate)
    }
    const confirm = await waitFor(() => findByCanonicalText(dialog, 'Tamam'))
    dispatch(confirm, 'click')
  }

  adapter.applyPlan = async function taxPatchedApplyPlan(plan) {
    if (!Array.isArray(plan) || !plan.length) return baseApplyPlan(plan)
    const taxes = plan.filter((item) => item?.kind === 'tax' || item?.kind === 'accommodation-tax')
    const nonTaxes = plan.filter((item) => item?.kind !== 'tax' && item?.kind !== 'accommodation-tax')
    const result = nonTaxes.length ? await baseApplyPlan(nonTaxes) : { writtenFieldCount: 0, taxActionCount: 0 }
    for (const action of taxes) await applyTaxAction(action)
    return {
      ...result,
      taxActionCount: taxes.length,
    }
  }

  adapter.__taxPatch136 = true
})()
