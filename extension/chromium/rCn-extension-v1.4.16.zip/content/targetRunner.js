(() => {
  const ROOT_ID = 'rcn-mikro-preview-root'
  let activeJob = null
  let activeProfile = null

  function removeOverlay() {
    document.getElementById(ROOT_ID)?.remove()
  }

  function normalize(value) {
    return String(value ?? '').trim().replace(/\s+/g, ' ').toLocaleLowerCase('tr-TR')
  }

  function formatMoney(value) {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(Number(value) || 0)
  }

  function createButton(label, className, handler) {
    const button = document.createElement('button')
    button.type = 'button'
    button.className = className
    button.textContent = label
    button.addEventListener('click', handler)
    return button
  }

  function showStatus(container, message, kind = 'info') {
    if (!container) return
    container.textContent = message
    container.dataset.kind = kind
  }

  function setText(root, selector, value) {
    const element = root.querySelector(selector)
    if (element) element.textContent = String(value ?? '-')
  }

  async function armUserDraftSave(event) {
    if (!activeJob) return
    const button = event.target?.closest?.('button')
    if (activeJob.localHotelBatch === true) {
      if (!button || normalize(button.textContent) !== 'gönder') return
      const status = document.querySelector(`#${ROOT_ID} [data-status]`)
      try {
        const response = await chrome.runtime.sendMessage({
          type: 'RCN_HOTEL_MARK_SEND_CLICKED',
          hotelBatchId: activeJob.hotelBatchId,
          hotelRowId: activeJob.hotelRowId,
        })
        if (!response?.ok) throw new Error(response?.error || 'Hotel listesi sıradaki kişiye geçirilemedi.')
        showStatus(status, 'Gönder düğmesi tıklamanız kaydedildi. Yeni faturada Hotel → Sıradakini Doldur ile devam edin.', 'success')
      } catch (error) {
        showStatus(status, error?.message || 'Hotel gönderim adımı kaydedilemedi.', 'error')
      }
      return
    }
    if (!button || normalize(button.textContent) !== 'taslaklara kaydet') return
    const serial = String(document.querySelector('#serialName')?.value || '').trim()
    const number = String(document.querySelector('#serialNumber')?.value || '').trim()
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'RCN_ARM_DRAFT_SAVE',
        operationKey: activeJob.operationKey,
        serial,
        number,
      })
      if (!response?.ok) throw new Error(response?.error || 'Taslak kaydetme kanıtı hazırlanamadı.')
      const status = document.querySelector(`#${ROOT_ID} [data-status]`)
      showStatus(status, `Mikro Taslak No ${serial}${number} izleniyor. Kaydetme başarılı olursa rCn sonucu otomatik alacak.`, 'success')
    } catch (error) {
      const status = document.querySelector(`#${ROOT_ID} [data-status]`)
      showStatus(status, error.message || 'Taslak kaydetme sonucu izlenemedi.', 'error')
    }
  }

  function reportSuccessfulSaveRedirect() {
    let url
    try { url = new URL(window.location.href) } catch (_) { return }
    const path = url.pathname.replace(/\/+$/, '').toLocaleLowerCase('tr-TR')
    const isDraftList = path.endsWith('/earchive/list') || path.endsWith('/newinvoice/list')
    if (!isDraftList || url.searchParams.get('loadFormData') !== 'true') return
    chrome.runtime.sendMessage({ type: 'RCN_TARGET_SAVE_REDIRECT', pageUrl: url.toString() }).catch(() => {})
  }

  function renderOverlay(job, profile) {
    removeOverlay()
    activeJob = job
    activeProfile = profile
    const invoice = job.invoice
    const root = document.createElement('aside')
    root.id = ROOT_ID
    root.innerHTML = `
      <style>
        #${ROOT_ID}{position:fixed;z-index:2147483647;right:18px;top:18px;width:min(420px,calc(100vw - 36px));max-height:calc(100vh - 36px);overflow:auto;background:#0b0f14;color:#f8fafc;border:1px solid rgba(96,255,88,.45);border-radius:16px;box-shadow:0 18px 60px rgba(0,0,0,.45),0 0 28px rgba(96,255,88,.12);font:14px/1.45 Inter,Segoe UI,sans-serif}
        #${ROOT_ID} *{box-sizing:border-box} #${ROOT_ID} header{padding:18px;border-bottom:1px solid rgba(255,255,255,.1);display:flex;justify-content:space-between;gap:12px} #${ROOT_ID} h2{font-size:18px;margin:0;color:#60ff58} #${ROOT_ID} p{margin:4px 0 0;color:#cbd5e1} #${ROOT_ID} main{padding:18px} #${ROOT_ID} dl{display:grid;grid-template-columns:120px 1fr;gap:8px;margin:0 0 16px} #${ROOT_ID} dt{color:#94a3b8} #${ROOT_ID} dd{margin:0;font-weight:700;word-break:break-word} #${ROOT_ID} ul{margin:8px 0 16px;padding-left:20px} #${ROOT_ID} footer{display:flex;flex-wrap:wrap;gap:8px;padding:0 18px 18px} #${ROOT_ID} button{border-radius:10px;padding:10px 12px;font-weight:700;cursor:pointer;border:1px solid rgba(255,255,255,.18)} #${ROOT_ID} .primary{background:#60ff58;color:#071007;border-color:#60ff58} #${ROOT_ID} .secondary{background:#151b23;color:#fff} #${ROOT_ID} .close{background:transparent;color:#cbd5e1} #${ROOT_ID} [data-status]{margin:0 18px 16px;padding:10px;border-radius:10px;background:#151b23;color:#dbeafe} #${ROOT_ID} [data-status][data-kind=error]{background:#3b1218;color:#fecaca} #${ROOT_ID} [data-status][data-kind=success]{background:#0f2b17;color:#bbf7d0}
      </style>
      <header><div><h2>${job.localHotelBatch === true ? 'rCn · Hotel Toplu Fatura' : 'rCn · Mikrogroup ePortal'}</h2><p>Yalnız taslak alanları doldurulur; resmî gönderim kullanıcıdadır.</p></div></header>
      <main>
        <dl>
          <dt>Belge</dt><dd data-value="document"></dd>
          <dt>Alıcı</dt><dd data-value="recipient"></dd>
          <dt>Kalem</dt><dd data-value="line-count"></dd>
          <dt>Toplam</dt><dd data-value="total"></dd>
          <dt>Ödeme</dt><dd data-value="payment"></dd>
          <dt>Profil</dt><dd data-value="profile"></dd>
        </dl>
        <strong>${job.localHotelBatch === true ? 'Fatura ayarları' : 'Şasi / motor önizlemesi'}</strong>
        <ul data-serials></ul>
      </main>
      <div data-status>Alanları doldurmadan önce Mikro ePortal sayfası ve gerçek DOM alanları doğrulanacaktır.</div>
      <footer></footer>
    `
    setText(root, '[data-value="document"]', invoice.document?.label || '-')
    setText(root, '[data-value="recipient"]', invoice.recipient?.title || '-')
    setText(root, '[data-value="line-count"]', invoice.lines?.length || 0)
    setText(root, '[data-value="total"]', formatMoney(invoice.totals?.gross))
    setText(root, '[data-value="payment"]', invoice.payment?.label || '-')
    setText(root, '[data-value="profile"]', profile.selectorVersion || 'Doğrulanmadı')
    const serialList = root.querySelector('[data-serials]')
    for (const line of invoice.lines || []) {
      const item = document.createElement('li')
      item.textContent = job.localHotelBatch === true
        ? `${line.name} · ${line.quantity} ${line.unit} · ${formatMoney(line.unitPrice)} · ${line.taxType}`
        : `${line.name || 'Ürün'}: ${line.chassisNo || 'Şasi yok'} / ${line.engineNo || 'Motor yok'}`
      serialList.appendChild(item)
    }
    const status = root.querySelector('[data-status]')
    const footer = root.querySelector('footer')
    footer.append(
      createButton('Alanları Kontrol Et', 'secondary', async () => {
        try {
          const prepared = await globalThis.RcnMikroAdapter.prepareTargetPage(document, activeJob, activeProfile)
          globalThis.RcnMikroAdapter.assertHotelFormReady(document, activeJob, activeProfile)
          const plan = globalThis.RcnMikroAdapter.buildPlan(document, activeJob, activeProfile)
          const taxCount = plan.filter((item) => item.kind === 'tax' || item.kind === 'accommodation-tax').length
          const fieldCount = plan.filter((item) => item.kind !== 'tax' && item.kind !== 'accommodation-tax').length
          showStatus(status, `${prepared.customerFormOpened ? 'Yeni alıcı formu açıldı · ' : ''}${fieldCount} alan doğrulandı${taxCount ? ` · ${taxCount} vergi adımı hazır` : ''}. Fatura kaydedilmedi veya gönderilmedi.`, 'success')
        } catch (error) {
          showStatus(status, error.message || 'Hedef sayfa doğrulanamadı.', 'error')
        }
      }),
      createButton('Formu Doldur', 'primary', async () => {
        try {
          await globalThis.RcnMikroAdapter.prepareTargetPage(document, activeJob, activeProfile)
          globalThis.RcnMikroAdapter.assertHotelFormReady(document, activeJob, activeProfile)
          const plan = globalThis.RcnMikroAdapter.buildPlan(document, activeJob, activeProfile)
          const result = await globalThis.RcnMikroAdapter.applyPlan(plan)
          const payable = activeJob.localHotelBatch === true
            ? await globalThis.RcnMikroAdapter.validatePayableTotal(document, activeJob.invoice.totals.gross)
            : null
          const response = await chrome.runtime.sendMessage({
            type: activeJob.localHotelBatch === true ? 'RCN_HOTEL_MARK_PREPARED' : 'RCN_MARK_FILLED',
            operationKey: activeJob.operationKey,
            hotelBatchId: activeJob.hotelBatchId,
            hotelRowId: activeJob.hotelRowId,
            writtenFieldCount: result.writtenFieldCount,
            selectorVersion: activeProfile.selectorVersion,
            payableTotalVerified: payable?.verified === true,
          })
          if (!response?.ok) throw new Error(response?.error || 'Form doldurma sonucu kaydedilemedi.')
          showStatus(status, `${result.writtenFieldCount} alan dolduruldu${result.taxActionCount ? ` · ${result.taxActionCount} vergi adımı uygulandı` : ''}${payable ? ` · ödenecek tutar ${formatMoney(payable.expected)} olarak doğrulandı` : ''}. ${activeJob.localHotelBatch === true ? 'Sıra, Mikro’daki Gönder düğmesine siz tıklayınca ilerleyecek.' : 'Taslaklara kaydet veya Gönder düğmesine basılmadı; son kontrol sizde.'}`, 'success')
        } catch (error) {
          showStatus(status, error.message || 'Form doldurulamadı. Hiçbir resmî işlem yapılmadı.', 'error')
        }
      }),
      createButton('Kapat', 'close', removeOverlay),
    )
    document.documentElement.appendChild(root)
  }

  document.addEventListener('click', armUserDraftSave, true)
  reportSuccessfulSaveRedirect()

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'RCN_PREVIEW_JOB') return false
    try {
      renderOverlay(message.job, message.profile)
      sendResponse({ ok: true })
    } catch (error) {
      sendResponse({ ok: false, error: error.message || 'Önizleme açılamadı.' })
    }
    return true
  })
})()
