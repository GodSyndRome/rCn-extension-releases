(() => {
  const GIB_ORIGIN = 'https://intvrg.gib.gov.tr'
  const GIB_SESSION_PATH = '/intvrg_side/main.jsp'
  const GIB_APP_NAME = 'tdvd'
  const PENDING_POLL_MS = 1500

  let dismissed = false
  let pollTimer = null
  let activeJobKey = ''

  function supportedGibSessionPage(locationLike) {
    try {
      const url = new URL(String(locationLike?.href || ''))
      return url.origin === GIB_ORIGIN
        && url.pathname === GIB_SESSION_PATH
        && url.searchParams.get('appName') === GIB_APP_NAME
    } catch (_) {
      return false
    }
  }

  function gibPageReference(locationLike) {
    if (!supportedGibSessionPage(locationLike)) return ''
    const clean = new URL(`${GIB_ORIGIN}${GIB_SESSION_PATH}`)
    clean.searchParams.set('appName', GIB_APP_NAME)
    return clean.toString()
  }

  if (!supportedGibSessionPage(window.location)) return

  function scheduleBoot(delay = PENDING_POLL_MS) {
    if (dismissed) return
    if (pollTimer) clearTimeout(pollTimer)
    pollTimer = setTimeout(() => {
      pollTimer = null
      boot().catch(() => {})
    }, delay)
  }

  function createPanel() {
    const existing = document.getElementById('rcn-gib-panel')
    if (existing) return existing
    if (dismissed) return null

    const host = document.createElement('section')
    host.id = 'rcn-gib-panel'
    host.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483647;width:min(390px,calc(100vw - 36px));background:#0b0f0d;color:#fff;border:1px solid rgba(96,255,88,.45);border-radius:14px;box-shadow:0 18px 55px rgba(0,0,0,.35);font:13px/1.45 Arial,sans-serif;padding:14px;'
    host.innerHTML = `
      <div style="display:flex;gap:10px;align-items:center;justify-content:space-between;margin-bottom:10px">
        <div><strong style="font-size:15px">rCn · GİB ÖTV 2A</strong><div id="rcn-gib-state" style="opacity:.72;margin-top:2px">rCn işi bekleniyor…</div></div>
        <button id="rcn-gib-close" type="button" style="background:transparent;color:#fff;border:0;font-size:18px;cursor:pointer">×</button>
      </div>
      <div id="rcn-gib-message" style="background:rgba(255,255,255,.06);padding:9px 10px;border-radius:10px;margin-bottom:10px">rCn satış ekranından hazırlanmış GİB işi bekleniyor.</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button id="rcn-gib-preview" type="button" disabled style="flex:1;min-width:130px;padding:9px 11px;border-radius:9px;border:1px solid #39443d;background:#151b17;color:#fff;cursor:pointer">Önizle</button>
        <button id="rcn-gib-fill" type="button" disabled style="flex:1;min-width:150px;padding:9px 11px;border-radius:9px;border:1px solid #60ff58;background:#60ff58;color:#071008;font-weight:700;cursor:pointer">Alanları Doldur</button>
      </div>
      <div style="opacity:.66;margin-top:9px;font-size:12px">Kaydet, beyannameyi ver, onayla, imzala veya ödeme işlemi otomatik yapılmaz.</div>
    `
    document.documentElement.appendChild(host)
    host.querySelector('#rcn-gib-close')?.addEventListener('click', () => {
      dismissed = true
      if (pollTimer) clearTimeout(pollTimer)
      pollTimer = null
      host.remove()
    })
    return host
  }

  function message(panel, value, error = false) {
    const target = panel?.querySelector('#rcn-gib-message')
    if (!target) return
    target.textContent = value
    target.style.color = error ? '#ff9d9d' : '#fff'
  }

  async function runtimeMessage(payload) {
    const response = await chrome.runtime.sendMessage(payload)
    if (!response?.ok) throw new Error(response?.error || 'GİB eklenti işlemi tamamlanamadı.')
    return response.result
  }

  function setWaiting(panel, detail = 'rCn satış ekranında GİB’e Hazırla ve Eklentiye Aktar işlemini başlatın. Bu panel işi otomatik algılayacaktır.') {
    const state = panel?.querySelector('#rcn-gib-state')
    const preview = panel?.querySelector('#rcn-gib-preview')
    const fill = panel?.querySelector('#rcn-gib-fill')
    if (state) state.textContent = 'rCn işi bekleniyor'
    if (preview) preview.disabled = true
    if (fill) fill.disabled = true
    message(panel, detail)
  }

  async function activateJob(panel, serverValidatedJob) {
    const state = panel.querySelector('#rcn-gib-state')
    const preview = panel.querySelector('#rcn-gib-preview')
    const fill = panel.querySelector('#rcn-gib-fill')

    if (!globalThis.rcnGibMacro) {
      state.textContent = 'GİB form bileşeni yüklenemedi'
      message(panel, 'rCn GİB alan doğrulama bileşeni yüklenemedi. İşlem durduruldu.', true)
      return
    }

    state.textContent = 'Sunucu doğrulaması yapılıyor…'
    try {
      await runtimeMessage({ type: 'RCN_GIB_VALIDATE_JOB' })
      const inspection = globalThis.rcnGibMacro.inspect(document)
      if (!inspection?.ok) throw new Error(inspection?.error || 'ÖTV 2A ekranı doğrulanamadı.')
      state.textContent = `Hazır · ${inspection.selectorVersion}`
      message(panel, 'Firma, cihaz ve iş zarfı sunucuda doğrulandı. Önce önizleme yapın; doldurma ayrıca sizin tıklamanızı bekler.')
      preview.disabled = false
      fill.disabled = false
    } catch (error) {
      activeJobKey = ''
      state.textContent = 'Hazırlık durduruldu'
      preview.disabled = true
      fill.disabled = true
      message(panel, error?.message || 'GİB işi doğrulanamadı.', true)
      scheduleBoot(3000)
      return
    }

    preview.onclick = async () => {
      preview.disabled = true
      try {
        const result = globalThis.rcnGibMacro.preview(document, serverValidatedJob)
        message(panel, `${result.fieldCount} GİB alanı doğrulandı. Resmî işlem düğmelerine dokunulmayacak.`)
      } catch (error) {
        message(panel, error?.message || 'GİB önizlemesi hazırlanamadı.', true)
      } finally {
        preview.disabled = false
      }
    }

    fill.onclick = async () => {
      fill.disabled = true
      preview.disabled = true
      try {
        message(panel, 'Alanlar hazırlanıyor. Taşıt, alış satıcısı ve alıcı GETİR sonuçları ile hisse %100 doğrulanacak…')
        const result = await globalThis.rcnGibMacro.fill(document, serverValidatedJob, true)
        const pageReference = gibPageReference(window.location)
        if (!pageReference) throw new Error('GİB oturum sayfası doğrulanamadı.')
        await runtimeMessage({
          type: 'RCN_GIB_REPORT_PREPARED',
          operationKey: serverValidatedJob.operationKey,
          writtenFieldCount: result.writtenFieldCount,
          selectorVersion: result.selectorVersion,
          pageUrl: pageReference,
          vehicleLookupClicked: result.vehicleLookupClicked === true,
          purchaseSellerLookupClicked: result.purchaseSellerLookupClicked === true,
          buyerLookupClicked: result.buyerLookupClicked === true,
          sharePercent: result.sharePercent,
          officialActionTriggered: result.officialActionTriggered === true,
        })
        state.textContent = 'Hazırlık tamamlandı'
        message(panel, 'Alanlar hazırlandı. GİB ekranındaki değerleri kontrol edin; Kaydet/Beyannameyi Ver/Onay/Ödeme işlemini yalnız siz yapabilirsiniz.')
      } catch (error) {
        message(panel, error?.message || 'GİB alanları hazırlanamadı.', true)
        fill.disabled = false
        preview.disabled = false
      }
    }
  }

  async function boot() {
    if (dismissed) return
    const panel = createPanel()
    if (!panel) return

    let pending
    try {
      pending = await runtimeMessage({ type: 'RCN_GIB_GET_PENDING' })
    } catch (error) {
      const state = panel.querySelector('#rcn-gib-state')
      if (state) state.textContent = 'Eklenti bağlantısı bekleniyor'
      message(panel, error?.message || 'rCn eklenti bağlantısı kontrol edilemedi.', true)
      scheduleBoot(2500)
      return
    }

    if (!pending?.job) {
      activeJobKey = ''
      setWaiting(panel)
      scheduleBoot()
      return
    }

    const serverValidatedJob = pending.job
    const jobKey = String(serverValidatedJob.operationKey || serverValidatedJob.id || 'pending')
    if (activeJobKey === jobKey) return
    activeJobKey = jobKey
    await activateJob(panel, serverValidatedJob)
  }

  boot().catch(() => {})
})()
