(() => {
  const adapter = globalThis.RcnMikroAdapter
  if (!adapter || adapter.__runtimePatch134) return

  const baseBuildPlan = adapter.buildPlan.bind(adapter)
  const baseApplyPlan = adapter.applyPlan.bind(adapter)
  const normalize = (value) => String(value ?? '').trim().replace(/\s+/g, ' ').toLocaleLowerCase('tr-TR')
  const text = (element) => String(element?.textContent || element?.innerText || element?.value || '').trim()
  const attr = (element, name) => String(element?.getAttribute?.(name) || '').trim()
  const queryAll = (root, selector) => {
    try { return Array.from(root?.querySelectorAll?.(selector) || []) } catch (_) { return [] }
  }
  const visible = (element) => {
    if (!element) return false
    const style = globalThis.getComputedStyle?.(element)
    return style ? style.display !== 'none' && style.visibility !== 'hidden' : true
  }
  const dispatch = (element, type) => {
    if (!element) return
    const EventCtor = type === 'click' ? (globalThis.MouseEvent || globalThis.Event) : globalThis.Event
    element.dispatchEvent(new EventCtor(type, { bubbles: true, cancelable: true }))
  }
  const waitFor = (check, timeoutMs = 5000, intervalMs = 60) => new Promise((resolve, reject) => {
    const startedAt = Date.now()
    const run = () => {
      try {
        const value = check()
        if (value) return resolve(value)
      } catch (_) { /* retry */ }
      if (Date.now() - startedAt >= timeoutMs) return reject(new Error('Mikro ePortal beklenen vergi alanını zamanında göstermedi. İşlem durduruldu.'))
      setTimeout(run, intervalMs)
    }
    run()
  })

  function findExactText(root, value) {
    const expected = normalize(value)
    return queryAll(root, 'label,span,p,div,button,li,a,[role="option"],[role="menuitem"]')
      .filter((element) => normalize(text(element)) === expected)
      .sort((first, second) => text(first).length - text(second).length)[0] || null
  }

  function closestDialog(element) {
    return element?.closest?.('[role="dialog"],.modal,.fds-modal,[class*="modal"]') || null
  }

  function controlCandidates(root) {
    return queryAll(root, 'select,[role="combobox"],search-dropdown,input[readonly][data-toggle="dropdown"]')
      .filter(visible)
  }

  function controlsNearLabel(label) {
    if (!label) return []
    const result = []
    const pushUnique = (items) => {
      for (const item of items) if (item && !result.includes(item)) result.push(item)
    }
    const htmlFor = attr(label, 'for') || String(label?.htmlFor || '').trim()
    if (htmlFor) pushUnique([document.getElementById?.(htmlFor)])
    let current = label.parentElement
    for (let depth = 0; current && depth < 5; depth += 1, current = current.parentElement) {
      pushUnique(controlCandidates(current))
      const sibling = current.nextElementSibling
      if (sibling) pushUnique(controlCandidates(sibling))
      if (result.length === 1) break
    }
    return result.filter(visible)
  }

  function findTaxTypeControl(dialog) {
    const candidates = controlCandidates(dialog)
    const byModel = candidates.find((element) => /selectedtax/i.test(attr(element, 'ng-model')))
    if (byModel) return byModel

    const label = findExactText(dialog, 'Vergi Türü')
    if (!label) return null
    const nearby = controlsNearLabel(label)
    if (nearby.length === 1) return nearby[0]

    const nativeSelects = queryAll(dialog, 'select').filter(visible)
    if (nativeSelects.length >= 2) {
      const exemptionLabel = findExactText(dialog, 'KDV İstisna Muafiyet Sebebi')
      if (exemptionLabel) return nativeSelects[1]
    }
    return nearby[0] || null
  }

  function chooseNativeSelect(select, value) {
    const expected = normalize(value)
    const option = Array.from(select?.options || []).find((item) => {
      const label = normalize(item?.textContent || item?.label)
      return label === expected || label.includes(expected)
    })
    if (!option) throw new Error(`${value} seçeneği Mikro ePortal Vergi Türü listesinde bulunamadı.`)
    select.value = option.value
    dispatch(select, 'input')
    dispatch(select, 'change')
  }

  async function chooseCustomControl(control, value) {
    const toggle = control?.matches?.('input,[role="combobox"]') ? control : control?.querySelector?.('[data-toggle="dropdown"],input[readonly],[role="combobox"]')
    if (!toggle) throw new Error('Mikro ePortal Vergi Türü seçim alanı açılamadı.')
    dispatch(toggle, 'click')
    const expected = normalize(value)
    const option = await waitFor(() => queryAll(control, 'li,a,button,[role="option"],.customer-list__item')
      .find((item) => normalize(text(item)) === expected || normalize(text(item)).includes(expected)))
    dispatch(option, 'click')
  }

  async function chooseTaxType(dialog, value) {
    const control = findTaxTypeControl(dialog)
    if (!control) throw new Error('Vergi Türü alanı bulunamadı. ÖTV eklenmedi.')
    if (String(control.tagName || '').toUpperCase() === 'SELECT') return chooseNativeSelect(control, value)
    return chooseCustomControl(control, value)
  }

  function findRateControl(dialog, taxLabel = 'ÖTV 2.LİSTE') {
    const numericInputs = queryAll(dialog, 'input[type="number"]')
      .filter((element) => visible(element) && !element.disabled && !element.readOnly)
    const byModel = numericInputs.find((element) => /(^|\.)rate$/i.test(attr(element, 'ng-model')) || /tax.*rate|rate.*tax/i.test(attr(element, 'ng-model')))
    if (byModel) return byModel

    const taxText = findExactText(dialog, taxLabel)
    if (taxText) {
      let current = taxText.parentElement
      for (let depth = 0; current && depth < 6; depth += 1, current = current.parentElement) {
        const controls = queryAll(current, 'input[type="number"]')
          .filter((element) => visible(element) && !element.disabled && !element.readOnly)
        if (controls.length === 1) return controls[0]
      }
    }
    return numericInputs.length === 1 ? numericInputs[0] : null
  }

  function writeNumber(element, value) {
    if (!element) return
    element.focus?.()
    element.value = String(value)
    for (const eventName of ['input', 'change', 'keyup', 'blur']) dispatch(element, eventName)
  }

  async function applyTaxAction(action) {
    dispatch(action.menu, 'click')
    const menuItem = await waitFor(() => findExactText(document, 'Vergi/Muafiyet'))
    dispatch(menuItem, 'click')

    const title = await waitFor(() => findExactText(document, 'Vergi/Muafiyet Bilgileri'))
    const dialog = closestDialog(title) || title.parentElement || document
    const existingTax = findExactText(dialog, 'ÖTV 2.LİSTE')

    if (!existingTax) {
      await chooseTaxType(dialog, 'ÖTV 2.LİSTE')
      const addTax = await waitFor(() => findExactText(dialog, 'Vergi Ekle'))
      dispatch(addTax, 'click')
      await waitFor(() => findExactText(dialog, 'ÖTV 2.LİSTE'))
    }

    const rateControl = await waitFor(() => findRateControl(dialog))
    writeNumber(rateControl, action.sctRate)
    const confirm = await waitFor(() => findExactText(dialog, 'Tamam'))
    dispatch(confirm, 'click')
  }

  function addRequiredUnitActions(plan, documentRef, job) {
    const lines = Array.isArray(job?.invoice?.lines) ? job.invoice.lines : []
    const unitControls = queryAll(documentRef, 'select[ng-model="d.Unit"]')
    lines.forEach((line, index) => {
      const element = unitControls[index]
      if (!element) throw new Error(`${index + 1}. kalem birim alanı Mikro ePortal'da bulunamadı. Hiçbir veri yazılmadı.`)
      const action = { kind: 'rcn-unit', element, value: line?.unit || 'Adet', lineIndex: index, label: `${index + 1}. kalem birim` }
      const quantityIndex = plan.findIndex((item) => item?.key === 'lineQuantity' && item?.lineIndex === index)
      plan.splice(quantityIndex >= 0 ? quantityIndex + 1 : plan.length, 0, action)
    })
  }

  function applyUnitAction(action) {
    const expected = normalize(action.value || 'Adet')
    const option = Array.from(action.element?.options || []).find((item) => {
      const label = normalize(item?.textContent || item?.label)
      return label === expected || (expected === 'adet' && label === 'adet')
    })
    if (!option) throw new Error(`${action.label} için ${String(action.value || 'Adet').toLocaleUpperCase('tr-TR')} birimi Mikro ePortal listesinde bulunamadı.`)
    action.element.value = option.value
    dispatch(action.element, 'input')
    dispatch(action.element, 'change')
    dispatch(action.element, 'blur')
  }

  function triggerLineRecalculation(plan) {
    const unitPriceFields = plan.filter((item) => item?.kind === 'field' && item?.key === 'lineUnitPrice')
    for (const item of unitPriceFields) {
      dispatch(item.element, 'keyup')
      dispatch(item.element, 'change')
      dispatch(item.element, 'blur')
    }
  }

  adapter.buildPlan = function patchedBuildPlan(documentRef, job, profile) {
    const plan = baseBuildPlan(documentRef, job, profile)
    addRequiredUnitActions(plan, documentRef, job)
    return plan
  }

  adapter.applyPlan = async function patchedApplyPlan(plan) {
    if (!Array.isArray(plan) || !plan.length) return baseApplyPlan(plan)
    const taxes = plan.filter((item) => item?.kind === 'tax')
    const accommodationTaxes = plan.filter((item) => item?.kind === 'accommodation-tax')
    const units = plan.filter((item) => item?.kind === 'rcn-unit')
    const basePlan = plan.filter((item) => item?.kind !== 'tax' && item?.kind !== 'rcn-unit' && item?.kind !== 'accommodation-tax')
    let result
    if (accommodationTaxes.length) {
      let writtenFieldCount = 0
      for (const action of plan) {
        if (action?.kind === 'rcn-unit') {
          applyUnitAction(action)
          writtenFieldCount += 1
        } else if (action?.kind !== 'tax' && action?.kind !== 'accommodation-tax') {
          const partial = await baseApplyPlan([action])
          writtenFieldCount += Number(partial?.writtenFieldCount || 0)
        }
      }
      triggerLineRecalculation(basePlan)
      for (const action of accommodationTaxes) await baseApplyPlan([action])
      result = { writtenFieldCount, taxActionCount: accommodationTaxes.length }
    } else {
      result = basePlan.length ? await baseApplyPlan(basePlan) : { writtenFieldCount: 0, taxActionCount: 0 }
      for (const action of units) applyUnitAction(action)
      triggerLineRecalculation(basePlan)
      result.writtenFieldCount = Number(result?.writtenFieldCount || 0) + units.length
    }
    for (const action of taxes) await applyTaxAction(action)
    return {
      ...result,
      taxActionCount: Number(result?.taxActionCount || 0) + taxes.length,
    }
  }

  adapter.__runtimePatch134 = true
})()
