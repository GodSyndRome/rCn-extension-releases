(() => {
  if (globalThis.__RCN_GIB_WEB_BRIDGE_V1__) return
  globalThis.__RCN_GIB_WEB_BRIDGE_V1__ = true

  const ALLOWED_RCN_ORIGIN = /^https:\/\/(?:[a-z0-9-]+\.)*rcn\.net\.tr$/i
  const WORKER_ORIGIN = 'https://rcnf.arcan.workers.dev'

  function allowedOrigin(value) {
    return ALLOWED_RCN_ORIGIN.test(String(value || '')) || value === WORKER_ORIGIN
  }
  if (!allowedOrigin(window.location.origin)) return

  const emit = (name, detail) => window.dispatchEvent(new CustomEvent(name, { detail }))

  window.addEventListener('rcn:gib-device-state-request', async () => {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'RCN_GIB_GET_PROFILE' })
      if (!response?.ok) throw new Error(response?.error || 'GİB eklenti durumu alınamadı.')
      emit('rcn:gib-device-state', response.result || { session: null, profile: null })
    } catch (error) {
      emit('rcn:gib-job-error', { message: error?.message || 'GİB eklenti durumu alınamadı.' })
    }
  })

  window.addEventListener('rcn:gib-job-ready', async (event) => {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'RCN_GIB_CAPTURE_JOB', payload: event.detail })
      if (!response?.ok) throw new Error(response?.error || 'GİB işi eklentiye aktarılamadı.')

      const target = await chrome.runtime.sendMessage({ type: 'RCN_GIB_OPEN_TARGET' })
      if (!target?.ok) throw new Error(target?.error || 'GİB İnternet Vergi Dairesi açılamadı.')

      const profile = await chrome.runtime.sendMessage({ type: 'RCN_GIB_GET_PROFILE' })
      emit('rcn:gib-job-captured', {
        ...response.result,
        profileReady: Boolean(profile?.ok && profile.result?.profile?.enabled && profile.result.profile.selectorVersion),
        sessionReady: target.result?.sessionReady === true,
        entryUrl: target.result?.url || profile?.result?.profile?.entryUrl || response.result?.entryUrl || '',
        selectorVersion: profile?.result?.profile?.selectorVersion || response.result?.selectorVersion || '',
      })
    } catch (error) {
      emit('rcn:gib-job-error', { message: error?.message || 'GİB işi eklentiye aktarılamadı.' })
    }
  })

  emit('rcn:gib-bridge-ready', { origin: window.location.origin })
})()
