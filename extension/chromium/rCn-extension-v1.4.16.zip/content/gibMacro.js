(() => {
  const profile = globalThis.RcnGibOtv2aProfile
  if (!profile) return

  const text = (value) => String(value ?? '').trim()
  const normalize = (value) => text(value).replace(/\s+/g, ' ').toLocaleUpperCase('tr-TR')
  const digits = (value) => text(value).replace(/\D/g, '')
  const comparable = (value) => normalize(value).replace(/[^0-9A-ZÇĞİÖŞÜ]/g, '')
  const FORBIDDEN_PAYLOAD_KEYS = /^(password|parola|secret|access_?token|refresh_?token|session_?token|card_?number|pan|cvv|cvc|sms_?code|otp)$/i
  const FORBIDDEN_ACTION_TEXT = /(kaydet|onayla|gönder|gonder|öde|ode|tahsil|sil|iptal|imzala|beyannameyi ver)/i
  const DYNAMIC_OPTION_TIMEOUT_MS = 15000
  const DYNAMIC_OPTION_POLL_MS = 160
  const DYNAMIC_OPTION_STABLE_CHECKS = 3

  class GibMacroError extends Error {
    constructor(code, message) {
      super(message)
      this.name = 'GibMacroError'
      this.code = code
    }
  }

  function fail(code, message) {
    throw new GibMacroError(code, message)
  }

  function assertNoSensitiveKeys(value, path = 'iş') {
    if (Array.isArray(value)) {
      value.forEach((item, index) => assertNoSensitiveKeys(item, `${path}[${index}]`))
      return
    }
    if (!value || typeof value !== 'object') return
    for (const [key, nested] of Object.entries(value)) {
      if (FORBIDDEN_PAYLOAD_KEYS.test(key)) fail('SENSITIVE_FIELD', `${path} içinde eklentiye aktarılmaması gereken alan bulundu: ${key}`)
      assertNoSensitiveKeys(nested, `${path}.${key}`)
    }
  }

  function queryOne(documentRef, selector, label) {
    let matches
    try {
      matches = Array.from(documentRef.querySelectorAll(selector))
    } catch (_) {
      fail('SELECTOR_INVALID', `${label} seçicisi geçerli değil.`)
    }
    if (matches.length !== 1) {
      fail('DOM_CHANGED', `${label} GİB ekranında beklenen tek alan olarak bulunamadı (${matches.length}). İşlem durduruldu.`)
    }
    return matches[0]
  }

  function assertContext(documentRef) {
    if (window.location.origin !== profile.origin) fail('ORIGIN_MISMATCH', 'Açık sayfa doğrulanmış GİB alan adı değil.')
    const missing = profile.pageMarkers.filter((selector) => {
      try { return documentRef.querySelectorAll(selector).length !== 1 } catch (_) { return true }
    })
    if (missing.length) fail('WRONG_PAGE', 'ÖTV 2A kara taşıtı beyanname ekranı doğrulanamadı. Form açıldıktan sonra tekrar deneyin.')
    const save = queryOne(documentRef, profile.selectors.saveButton, 'GİB Kaydet düğmesi')
    if (!FORBIDDEN_ACTION_TEXT.test(text(save.value || save.textContent))) fail('SAVE_MARKER_CHANGED', 'GİB Kaydet düğmesi beklenen yapıda değil; otomasyon durduruldu.')
  }

  function parsePayload(job) {
    if (!job || typeof job !== 'object') fail('INVALID_JOB', 'GİB aktarım işi bulunamadı.')
    assertNoSensitiveKeys(job)
    if (job.adapterKey && job.adapterKey !== profile.key) fail('INVALID_ADAPTER', 'İş GİB adaptörüne ait değil.')
    if (job.operation && job.operation !== profile.operation) fail('UNSAFE_OPERATION', 'Bu eklenti yalnız ÖTV 2A alan hazırlığını yapabilir.')
    const payload = job.gib || job.payload || job
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) fail('INVALID_PAYLOAD', 'GİB veri paketi bulunamadı.')
    if (![3, 4].includes(Number(payload.schemaVersion || 3))) fail('UNSUPPORTED_SCHEMA', 'GİB veri paketi sürümü desteklenmiyor.')
    if (payload.declarationType !== profile.declarationType) fail('DECLARATION_TYPE', 'Yalnız ÖTV 2A kara taşıtı beyanı desteklenir.')

    const vehicle = payload.vehicle || {}
    if (!text(vehicle.chassisNo) || !text(vehicle.engineNo)) fail('SERIAL_REQUIRED', 'Şasi ve motor numarası rCn satış kaydından gelmelidir.')
    for (const [key, label] of [
      ['gibCategory', 'araç sınıf kategorisi'],
      ['brand', 'marka'],
      ['bodyDescription', 'üst yapı gövde tanımı'],
      ['fuelType', 'yakıt türü'],
      ['modelYear', 'model yılı'],
    ]) {
      if (!text(vehicle[key])) fail('VEHICLE_FIELD_REQUIRED', `Uygunluk belgesinden ${label} okunmadan GİB hazırlığı yapılamaz.`)
    }
    if (payload.vehicleLookupRequired !== true) fail('VEHICLE_LOOKUP_REQUIRED', 'Taşıt bilgileri GİB GETİR doğrulamasından geçmelidir.')

    const purchase = payload.purchase || {}
    const sellerTaxNo = digits(purchase.seller?.taxNo)
    if (sellerTaxNo.length !== 10) fail('PURCHASE_VKN_REQUIRED', 'Alış faturası satıcı VKN bilgisi 10 haneli olmalıdır.')
    if (!text(purchase.invoice?.number) || !text(purchase.invoice?.date)) fail('PURCHASE_INVOICE_REQUIRED', 'Alış faturası numarası ve tarihi zorunludur.')
    if (!(Number(purchase.invoice?.vatBase) > 0)) fail('PURCHASE_BASE_REQUIRED', 'Alış faturası araç başına KDV matrahı geçerli değil.')

    const tax = payload.tax || {}
    if (!(Number(tax.taxableBase) > 0) || !(Number(tax.sctRate) >= 0)) fail('INVALID_TAX', 'ÖTV matrahı veya ÖTV oranı geçerli değil.')

    const buyer = payload.sale?.buyer || payload.buyer || {}
    const buyerIdentity = digits(buyer.identityNo || buyer.taxNo)
    if (![10, 11].includes(buyerIdentity.length)) fail('BUYER_ID_REQUIRED', 'Alıcı TCKN/VKN bilgisi rCn satış kaydından gelmelidir.')
    if (payload.protestReservation?.enabled !== true) fail('PROTEST_REQUIRED', 'Bu akış ihtirazi kayıt seçeneği açık olarak hazırlanmalıdır.')
    if (Number(payload.protestReservation?.sharePercent) !== 100) fail('INVALID_SHARE', 'Alıcı hissesi yalnız %100 olabilir.')

    const evidence = payload.pdfEvidence || {}
    for (const requiredKey of profile.pdfEvidence.required) {
      const item = evidence[requiredKey]
      if (!item || !text(item.fileName) || !(Number(item.sizeBytes) > 0) || !/^[a-f0-9]{64}$/i.test(text(item.sha256))) {
        fail('PDF_EVIDENCE_REQUIRED', `${requiredKey} PDF kanıtı eksik veya doğrulanmamış.`)
      }
    }
    const optionalSaleInvoice = evidence.saleInvoice
    if (optionalSaleInvoice && (!text(optionalSaleInvoice.fileName) || !(Number(optionalSaleInvoice.sizeBytes) > 0) || !/^[a-f0-9]{64}$/i.test(text(optionalSaleInvoice.sha256)))) {
      fail('OPTIONAL_PDF_INVALID', 'Satış faturası yüklendiyse boyut ve SHA-256 doğrulaması tamamlanmalıdır.')
    }
    return payload
  }

  function nativeValueSetter(element, value) {
    const tag = text(element.tagName).toUpperCase()
    const prototype = tag === 'TEXTAREA'
      ? window.HTMLTextAreaElement?.prototype
      : tag === 'SELECT'
        ? window.HTMLSelectElement?.prototype
        : window.HTMLInputElement?.prototype
    const descriptor = prototype ? Object.getOwnPropertyDescriptor(prototype, 'value') : null
    if (descriptor?.set) descriptor.set.call(element, value)
    else element.value = value
    element.dispatchEvent(new Event('input', { bubbles: true }))
    element.dispatchEvent(new Event('change', { bubbles: true }))
    element.dispatchEvent(new Event('blur', { bubbles: true }))
  }

  function nativeCheckedSetter(element, checked) {
    const descriptor = window.HTMLInputElement?.prototype
      ? Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'checked')
      : null
    if (descriptor?.set) descriptor.set.call(element, Boolean(checked))
    else element.checked = Boolean(checked)
    element.dispatchEvent(new Event('input', { bubbles: true }))
    element.dispatchEvent(new Event('change', { bubbles: true }))
    element.dispatchEvent(new Event('blur', { bubbles: true }))
  }

  function turkishDecimal(value) {
    const number = Number(value)
    if (!Number.isFinite(number)) return ''
    return number.toFixed(2).replace('.', ',')
  }

  function turkishDate(value) {
    const raw = text(value)
    const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/)
    return iso ? `${iso[3]}.${iso[2]}.${iso[1]}` : raw
  }

  function findChoice(element, desired) {
    const target = normalize(desired)
    if (!target) return null
    const options = Array.from(element.options || [])
    const exactMatches = options.filter((option) => normalize(option.value) === target || normalize(option.textContent) === target)
    if (exactMatches.length === 1) return exactMatches[0]
    if (exactMatches.length > 1) return null
    const prefixedMatches = options.filter((option) => normalize(option.textContent).startsWith(`${target} `))
    return prefixedMatches.length === 1 ? prefixedMatches[0] : null
  }

  function selectChoice(element, desired, label) {
    const match = findChoice(element, desired)
    if (!match) fail('OPTION_NOT_FOUND', `${label} seçeneği GİB listesindeki güncel seçeneklerle tekil olarak eşleşmedi.`)
    nativeValueSetter(element, match.value)
  }

  function optionSignature(element) {
    return Array.from(element.options || [])
      .map((option) => `${text(option.value)}=${normalize(option.textContent)}`)
      .join('|')
  }

  function selectedChoiceMatches(element, desired) {
    const match = findChoice(element, desired)
    if (!match) return false
    return text(element.value) === text(match.value)
  }

  async function waitForStableDynamicChoice(documentRef, key, label, desired, timeoutMs = DYNAMIC_OPTION_TIMEOUT_MS) {
    const started = Date.now()
    let lastSignature = ''
    let stableChecks = 0

    while (Date.now() - started < timeoutMs) {
      try {
        const element = field(documentRef, key, label)
        const signature = optionSignature(element)
        const match = element.disabled === true ? null : findChoice(element, desired)
        if (match && signature && signature === lastSignature) stableChecks += 1
        else stableChecks = match ? 1 : 0
        lastSignature = signature
        if (stableChecks >= DYNAMIC_OPTION_STABLE_CHECKS) return
      } catch (_) {
        lastSignature = ''
        stableChecks = 0
      }
      await new Promise((resolve) => setTimeout(resolve, DYNAMIC_OPTION_POLL_MS))
    }

    fail('DYNAMIC_OPTION_TIMEOUT', `${label} GİB listesi ${Math.round(timeoutMs / 1000)} saniye içinde yüklenmedi veya tekil eşleşme sabitlenmedi.`)
  }

  async function selectStableDynamicChoice(documentRef, key, label, desired) {
    await waitForStableDynamicChoice(documentRef, key, label, desired)
    selectChoice(field(documentRef, key, label), desired, label)
    await waitFor(
      () => selectedChoiceMatches(field(documentRef, key, label), desired),
      `${label} seçimi GİB tarafından korunmadı. Alan yeniden yüklendiği için işlem durduruldu.`,
      3000,
    )
  }

  function setChecked(element, checked, label) {
    if (text(element.type).toLowerCase() !== 'checkbox') fail('CHECKBOX_TARGET', `${label} hedefi checkbox değil.`)
    if (Boolean(element.checked) !== Boolean(checked)) nativeCheckedSetter(element, checked)
    if (Boolean(element.checked) !== Boolean(checked)) fail('CHECKBOX_WRITE_FAILED', `${label} işaretlenemedi.`)
  }

  function exactGetir(element, label) {
    const actionText = normalize(element.textContent || element.value)
    if (actionText !== 'GETİR') fail('LOOKUP_CHANGED', `${label} yalnız tam “GETİR” işlemi olduğunda çalıştırılabilir.`)
    if (FORBIDDEN_ACTION_TEXT.test(actionText)) fail('UNSAFE_LOOKUP', `${label} resmî işlem düğmesiyle çakışıyor.`)
    element.click()
  }

  function lookupEnabled(element) {
    return !element.classList?.contains('csc-link-disabled')
      && element.getAttribute?.('aria-disabled') !== 'true'
      && element.disabled !== true
  }

  async function waitFor(predicate, message, timeoutMs = DYNAMIC_OPTION_TIMEOUT_MS) {
    const started = Date.now()
    while (Date.now() - started < timeoutMs) {
      try {
        if (predicate()) return
      } catch (_) {
        // Dinamik GİB alanı henüz oluşmadıysa süre dolana kadar beklenir.
      }
      await new Promise((resolve) => setTimeout(resolve, 120))
    }
    fail('LOOKUP_TIMEOUT', message)
  }

  function field(documentRef, key, label) {
    return queryOne(documentRef, profile.selectors[key], label)
  }

  function readOnlyText(documentRef, key) {
    const selector = profile.readOnlySelectors[key]
    if (!selector) return ''
    try {
      const matches = documentRef.querySelectorAll(selector)
      return matches.length === 1 ? text(matches[0].textContent) : ''
    } catch (_) {
      return ''
    }
  }

  function verifyReadOnly(documentRef, key, expected, label) {
    if (!text(expected)) return
    const actual = readOnlyText(documentRef, key)
    if (!actual || normalize(actual) === '-----') fail('VEHICLE_LOOKUP_EMPTY', `${label} GİB GETİR sonucunda oluşmadı.`)
    const left = comparable(actual)
    const right = comparable(expected)
    if (right && left && !left.includes(right) && !right.includes(left)) {
      fail('VEHICLE_LOOKUP_MISMATCH', `${label} GİB sonucu uygunluk belgesiyle uyuşmuyor.`)
    }
  }

  function preview(documentRef, job) {
    assertContext(documentRef)
    const payload = parsePayload(job)
    const selectors = profile.selectors
    const coreKeys = [
      'chassisNo', 'engineNo', 'vehicleCategory', 'vehicleBrand', 'bodyDescription', 'fuelType', 'modelYear', 'vehicleLookupButton',
      'purchaseRole', 'purchaseSellerTaxNo', 'purchaseSellerLookupButton', 'purchaseInvoiceDate', 'purchaseInvoiceNo', 'purchaseVatBase',
      'exemption', 'taxableBase', 'sctRate', 'protestReservation', 'buyerIdentityNo', 'buyerLookupButton', 'sharePercent',
    ]
    for (const key of coreKeys) queryOne(documentRef, selectors[key], key)
    return {
      ok: true,
      selectorVersion: profile.selectorVersion,
      fieldCount: coreKeys.length,
      optionalSaleInvoiceEvidence: Boolean(payload.pdfEvidence?.saleInvoice),
      officialActionTriggered: false,
    }
  }

  async function fill(documentRef, job, userApproved) {
    if (userApproved !== true) fail('USER_APPROVAL_REQUIRED', 'GİB alanlarını doldurmak için kullanıcı onayı zorunludur.')
    assertContext(documentRef)
    const payload = parsePayload(job)
    const vehicle = payload.vehicle || {}
    const purchase = payload.purchase || {}
    const tax = payload.tax || {}
    const buyer = payload.sale?.buyer || payload.buyer || {}
    let writtenFieldCount = 0

    nativeValueSetter(field(documentRef, 'chassisNo', 'Şasi numarası'), text(vehicle.chassisNo)); writtenFieldCount += 1
    nativeValueSetter(field(documentRef, 'engineNo', 'Motor numarası'), text(vehicle.engineNo)); writtenFieldCount += 1

    selectChoice(field(documentRef, 'vehicleCategory', 'Araç sınıf kategorisi'), vehicle.gibCategory, 'Araç sınıf kategorisi'); writtenFieldCount += 1
    await selectStableDynamicChoice(documentRef, 'vehicleBrand', 'Marka', vehicle.brand); writtenFieldCount += 1
    await selectStableDynamicChoice(documentRef, 'bodyDescription', 'Üst yapı gövde tanımı', vehicle.bodyDescription); writtenFieldCount += 1
    await selectStableDynamicChoice(documentRef, 'fuelType', 'Yakıt türü', vehicle.fuelType); writtenFieldCount += 1
    await selectStableDynamicChoice(documentRef, 'modelYear', 'Model yılı', vehicle.modelYear); writtenFieldCount += 1

    const vehicleLookup = field(documentRef, 'vehicleLookupButton', 'Araç GETİR')
    await waitFor(() => lookupEnabled(field(documentRef, 'vehicleLookupButton', 'Araç GETİR')), 'Araç GETİR bağlantısı kullanıma açılmadı.')
    exactGetir(field(documentRef, 'vehicleLookupButton', 'Araç GETİR'), 'Araç GETİR')
    await waitFor(() => {
      const current = normalize(readOnlyText(documentRef, 'commercialName'))
      return current && current !== '-----'
    }, 'GİB araç bilgileri GETİR sonrası zamanında yüklenmedi.')
    verifyReadOnly(documentRef, 'commercialName', vehicle.commercialName, 'Ticari ad')
    verifyReadOnly(documentRef, 'engineCapacity', vehicle.engineCapacity, 'Motor silindir hacmi')
    verifyReadOnly(documentRef, 'maxNetPower', vehicle.maxNetPower, 'Motor gücü')
    verifyReadOnly(documentRef, 'environmentalStep', vehicle.environmentalStep, 'Euro standardı')

    selectChoice(field(documentRef, 'purchaseRole', 'Aracın alış rolü'), purchase.role || profile.defaults.purchaseRole, 'Aracın alış rolü'); writtenFieldCount += 1
    nativeValueSetter(field(documentRef, 'purchaseSellerTaxNo', 'Alış satıcısı VKN'), digits(purchase.seller?.taxNo)); writtenFieldCount += 1

    await waitFor(() => lookupEnabled(field(documentRef, 'purchaseSellerLookupButton', 'Alış satıcısı GETİR')), 'Alış satıcısı GETİR bağlantısı VKN sonrasında kullanıma açılmadı.')
    exactGetir(field(documentRef, 'purchaseSellerLookupButton', 'Alış satıcısı GETİR'), 'Alış satıcısı GETİR')
    await waitFor(() => {
      const current = normalize(readOnlyText(documentRef, 'purchaseSellerTitle'))
      return current && current !== '-----'
    }, 'Alış satıcısı GETİR sonucu zamanında yüklenmedi.')

    nativeValueSetter(field(documentRef, 'purchaseInvoiceDate', 'Alış faturası tarihi'), turkishDate(purchase.invoice?.date)); writtenFieldCount += 1
    nativeValueSetter(field(documentRef, 'purchaseInvoiceNo', 'Alış faturası numarası'), text(purchase.invoice?.number)); writtenFieldCount += 1
    nativeValueSetter(field(documentRef, 'purchaseVatBase', 'Alış KDV matrahı'), turkishDecimal(purchase.invoice?.vatBase)); writtenFieldCount += 1

    selectChoice(field(documentRef, 'exemption', 'İstisna'), payload.sale?.exemption || profile.defaults.exemption, 'İstisna'); writtenFieldCount += 1
    nativeValueSetter(field(documentRef, 'taxableBase', 'ÖTV matrahı'), turkishDecimal(tax.taxableBase)); writtenFieldCount += 1
    nativeValueSetter(field(documentRef, 'sctRate', 'ÖTV oranı'), turkishDecimal(tax.sctRate)); writtenFieldCount += 1

    setChecked(field(documentRef, 'protestReservation', 'İhtirazi kayıt'), true, 'İhtirazi kayıt'); writtenFieldCount += 1
    nativeValueSetter(field(documentRef, 'buyerIdentityNo', 'Alıcı TCKN/VKN'), digits(buyer.identityNo || buyer.taxNo)); writtenFieldCount += 1
    await waitFor(() => lookupEnabled(field(documentRef, 'buyerLookupButton', 'Alıcı GETİR')), 'Alıcı GETİR bağlantısı kimlik numarası sonrasında kullanıma açılmadı.')
    exactGetir(field(documentRef, 'buyerLookupButton', 'Alıcı GETİR'), 'Alıcı GETİR')
    await waitFor(() => !field(documentRef, 'sharePercent', 'Alıcı hissesi').disabled, 'Alıcı GETİR sonrası hisse alanı kullanıma açılmadı.')
    nativeValueSetter(field(documentRef, 'sharePercent', 'Alıcı hissesi'), '100'); writtenFieldCount += 1

    return {
      ok: true,
      selectorVersion: profile.selectorVersion,
      writtenFieldCount,
      vehicleLookupClicked: true,
      purchaseSellerLookupClicked: true,
      buyerLookupClicked: true,
      sharePercent: 100,
      officialActionTriggered: false,
      requiresFinalUserReview: true,
    }
  }

  function inspect(documentRef) {
    try {
      assertContext(documentRef)
      const selectors = Object.entries(profile.selectors)
        .filter(([key]) => key !== 'saveButton')
        .map(([key, selector]) => ({ key, count: documentRef.querySelectorAll(selector).length }))
      return {
        ok: selectors.every((item) => item.count === 1),
        selectorVersion: profile.selectorVersion,
        selectors,
        officialActionTriggered: false,
      }
    } catch (error) {
      return { ok: false, code: error.code || 'INSPECT_FAILED', error: error.message || 'GİB ekranı doğrulanamadı.' }
    }
  }

  globalThis.rcnGibMacro = Object.freeze({ inspect, preview, fill, profile })

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || !['RCN_GIB_INSPECT', 'RCN_GIB_PREVIEW', 'RCN_GIB_FILL'].includes(message.type)) return false
    ;(async () => {
      if (message.type === 'RCN_GIB_INSPECT') return inspect(document)
      if (message.type === 'RCN_GIB_PREVIEW') return preview(document, message.job)
      return fill(document, message.job, message.userApproved === true)
    })().then(
      (result) => sendResponse({ ok: true, result }),
      (error) => sendResponse({ ok: false, code: error.code || 'GIB_ERROR', error: error.message || 'GİB işlemi tamamlanamadı.' }),
    )
    return true
  })
})()