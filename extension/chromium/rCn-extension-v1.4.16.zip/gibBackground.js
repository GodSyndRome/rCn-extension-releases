import { ensureDeviceSession } from './lib/deviceSession.js'
import { callGibJobProxy } from './lib/gibJobClient.js'

const GIB_PENDING_KEY = 'rcn.gib.pending.v1'
const GIB_ORIGIN = 'https://intvrg.gib.gov.tr'
const GIB_ENTRY_URL = `${GIB_ORIGIN}/`
const GIB_TAB_PATTERN = `${GIB_ORIGIN}/*`
const GIB_SELECTOR_VERSION = 'intvrg-otv2a-rel-2026-08-23-v1'
const GIB_ADAPTER = 'gib_ebeyan'
const GIB_OPERATION = 'prepare_otv2a_declaration'
const GIB_PERMISSION = 'gib_ebeyan:prepare_otv2a_declaration'
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
const SERVER_SIGNATURE_PATTERN = /^[A-Za-z0-9_-]{32,256}$/
const SENSITIVE_KEY = /^(password|parola|secret|access_?token|refresh_?token|session_?token|service_?role|card_?number|pan|cvv|cvc|sms_?code|otp)$/i

function text(value) { return String(value ?? '').trim() }
function isObject(value) { return Boolean(value) && typeof value === 'object' && !Array.isArray(value) }
function uuid(value) { return UUID_PATTERN.test(text(value)) }

function isGibSessionUrl(rawUrl) {
  try {
    const url = new URL(String(rawUrl || ''))
    return url.origin === GIB_ORIGIN
      && url.pathname === '/intvrg_side/main.jsp'
      && String(url.searchParams.get('appName') || '').toLocaleLowerCase('en-US') === 'tdvd'
      && Boolean(String(url.searchParams.get('token') || '').trim())
  } catch (_) {
    return false
  }
}

function assertNoSensitiveKeys(value, path = 'iş') {
  if (Array.isArray(value)) return value.forEach((item, index) => assertNoSensitiveKeys(item, `${path}[${index}]`))
  if (!isObject(value)) return
  for (const [key, nested] of Object.entries(value)) {
    if (SENSITIVE_KEY.test(key)) throw new Error(`${path} içinde eklentiye aktarılmaması gereken alan bulundu: ${key}`)
    assertNoSensitiveKeys(nested, `${path}.${key}`)
  }
}

function validateEnvelope(payload) {
  if (!isObject(payload) || payload.source !== 'rcn-app' || payload.channel !== 'rcn-extension-v2' || payload.type !== 'RCN_INTEGRATION_JOB_READY') throw new Error('GİB iş zarfı doğrulanamadı.')
  const job = payload.job
  if (!isObject(job) || Number(job.schemaVersion) !== 2) throw new Error('GİB eklenti işi sürümü desteklenmiyor.')
  assertNoSensitiveKeys(job)
  for (const [value, label] of [[job.jobId, 'İş'], [job.sourceRecordId, 'Satış'], [job.userId, 'Kullanıcı'], [job.companyId, 'Firma'], [job.deviceId, 'Cihaz']]) {
    if (!uuid(value)) throw new Error(`${label} kimliği geçerli değil.`)
  }
  if (job.branchId && !uuid(job.branchId)) throw new Error('Şube kimliği geçerli değil.')
  if (job.sourceType !== 'dealer_vehicle_sale') throw new Error('GİB işi yalnız araç satışı kaynağından hazırlanabilir.')
  if (job.adapterKey !== GIB_ADAPTER || job.operation !== GIB_OPERATION || job.permissionScope !== GIB_PERMISSION) throw new Error('GİB iş kapsamı geçerli değil.')
  if (!SERVER_SIGNATURE_PATTERN.test(text(job.serverSignature))) throw new Error('GİB sunucu kanıtı geçerli değil.')
  if (!isObject(job.gib) || Number(job.gib.schemaVersion) !== 3 || job.gib.declarationType !== 'otv_2a_kara') throw new Error('GİB ÖTV 2A veri paketi bulunamadı.')
  if (Date.parse(job.expiresAt) <= Date.now()) throw new Error('GİB işinin süresi dolmuş.')
  return job
}

function publicSession(session) {
  if (!session) return null
  return {
    deviceId: session.deviceId,
    companyId: session.companyId,
    companyName: session.companyName || '',
    branchId: session.branchId || null,
    branchName: session.branchName || '',
    profileId: session.profileId || null,
    profileName: session.profileName || '',
    deviceFingerprint: session.deviceFingerprint || '',
    permissionScopes: Array.isArray(session.permissionScopes) ? session.permissionScopes : [],
    expiresAt: session.expiresAt || null,
  }
}

async function freshSession() { return ensureDeviceSession() }

async function captureGibJob(payload) {
  const job = validateEnvelope(payload)
  const session = await freshSession()
  if (session.deviceId !== job.deviceId || session.companyId !== job.companyId || (session.branchId || null) !== (job.branchId || null)) throw new Error('GİB işi eklenti cihazı, firma veya şube kapsamıyla uyuşmuyor.')
  // GİB izni iş oluşturulurken sunucuda cihaz + aktif oturuma eklenir. Yerel permissionScopes
  // anlık olarak eski kalabileceği için burada otorite değildir; asıl yetki RCN_GIB_VALIDATE_JOB sırasında DB oturumundan doğrulanır.
  const stored = await chrome.storage.session.get(GIB_PENDING_KEY)
  const current = stored[GIB_PENDING_KEY]
  if (current?.payload?.job?.operationKey === job.operationKey && Date.parse(current.expiresAt || '') > Date.now()) {
    return { duplicate: true, jobId: job.jobId, operationKey: job.operationKey, entryUrl: GIB_ENTRY_URL, selectorVersion: GIB_SELECTOR_VERSION }
  }
  await chrome.storage.session.set({ [GIB_PENDING_KEY]: { payload, capturedAt: new Date().toISOString(), expiresAt: job.expiresAt } })
  return { duplicate: false, jobId: job.jobId, operationKey: job.operationKey, entryUrl: GIB_ENTRY_URL, selectorVersion: GIB_SELECTOR_VERSION }
}

async function getPending() {
  const stored = await chrome.storage.session.get(GIB_PENDING_KEY)
  const pending = stored[GIB_PENDING_KEY]
  if (!pending?.payload?.job) return null
  if (Date.parse(pending.expiresAt || pending.payload.job.expiresAt || '') <= Date.now()) {
    await chrome.storage.session.remove(GIB_PENDING_KEY)
    return null
  }
  const session = await freshSession()
  const job = validateEnvelope(pending.payload)
  if (session.deviceId !== job.deviceId || session.companyId !== job.companyId || (session.branchId || null) !== (job.branchId || null)) return null
  return pending.payload
}

async function openGibTarget() {
  const tabs = await chrome.tabs.query({ url: GIB_TAB_PATTERN })
  const sessionTab = tabs.find((tab) => isGibSessionUrl(tab?.url))
  const tab = sessionTab || tabs[0]
  if (tab?.id) {
    await chrome.tabs.update(tab.id, { active: true })
    if (tab.windowId != null && chrome.windows?.update) await chrome.windows.update(tab.windowId, { focused: true })
    return { tabId: tab.id, url: isGibSessionUrl(tab.url) ? `${GIB_ORIGIN}/intvrg_side/main.jsp?appName=tdvd` : GIB_ENTRY_URL, sessionReady: Boolean(sessionTab) }
  }
  const created = await chrome.tabs.create({ url: GIB_ENTRY_URL, active: true })
  return { tabId: created.id, url: GIB_ENTRY_URL, sessionReady: false }
}

async function validatePendingJob() {
  const pending = await getPending()
  if (!pending?.job) throw new Error('Bekleyen GİB işi bulunamadı veya süresi doldu.')
  const result = await callGibJobProxy({ action: 'validate', job: pending.job })
  return result.payload
}

async function reportPrepared(input) {
  const pending = await getPending()
  if (!pending?.job) throw new Error('Bekleyen GİB işi bulunamadı veya süresi doldu.')
  if (input.operationKey !== pending.job.operationKey) throw new Error('GİB hazırlık sonucu bekleyen işle eşleşmiyor.')
  if (input.officialActionTriggered === true) throw new Error('Resmî GİB işlemi otomatik tetiklenmiş olamaz.')
  if (input.vehicleLookupClicked !== true || input.purchaseSellerLookupClicked !== true || input.buyerLookupClicked !== true || Number(input.sharePercent) !== 100) {
    throw new Error('Taşıt GETİR, alış satıcısı GETİR, alıcı GETİR ve %100 hisse doğrulaması tamamlanmadı.')
  }
  const result = await callGibJobProxy({
    action: 'report_prepared',
    operationKey: pending.job.operationKey,
    writtenFieldCount: Math.max(0, Number(input.writtenFieldCount) || 0),
    selectorVersion: text(input.selectorVersion || GIB_SELECTOR_VERSION),
    pageUrl: text(input.pageUrl),
    vehicleLookupClicked: true,
    purchaseSellerLookupClicked: true,
    buyerLookupClicked: true,
    sharePercent: 100,
    officialActionTriggered: false,
  })
  await chrome.storage.session.remove(GIB_PENDING_KEY)
  return result.payload
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || !String(message.type || '').startsWith('RCN_GIB_')) return false
  ;(async () => {
    if (message.type === 'RCN_GIB_GET_PROFILE') {
      const session = await freshSession().catch(() => null)
      return { profile: { enabled: true, origin: GIB_ORIGIN, entryUrl: GIB_ENTRY_URL, selectorVersion: GIB_SELECTOR_VERSION, pageMarkerCount: 5 }, session: publicSession(session) }
    }
    if (message.type === 'RCN_GIB_CAPTURE_JOB') return captureGibJob(message.payload)
    if (message.type === 'RCN_GIB_GET_PENDING') return getPending()
    if (message.type === 'RCN_GIB_OPEN_TARGET') return openGibTarget()
    if (message.type === 'RCN_GIB_VALIDATE_JOB') return validatePendingJob()
    if (message.type === 'RCN_GIB_REPORT_PREPARED') return reportPrepared(message)
    throw new Error('Desteklenmeyen GİB eklenti mesajı.')
  })().then(
    (result) => sendResponse({ ok: true, result }),
    (error) => sendResponse({ ok: false, error: error?.message || 'GİB eklenti işlemi tamamlanamadı.' }),
  )
  return true
})
