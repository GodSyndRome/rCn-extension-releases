import { inspectHotelInvoiceFile } from './lib/hotelInvoiceWorkbook.js'

const status = document.getElementById('status')
const jobsRoot = document.getElementById('jobs')
const sessionDetails = document.getElementById('session-details')
const systemDetails = document.getElementById('system-details')
const permissionsRoot = document.getElementById('permissions')
const sessionBadge = document.getElementById('session-badge')
const jobCount = document.getElementById('job-count')
const logoutButton = document.getElementById('logout')
const MIKRO_TAB_PATTERN = 'https://eportal.mikrogrup.com/*'
const MIKRO_CONTENT_FILES = ['webextCompat.js', 'content/mikroAdapter.js', 'content/mikroRuntimePatch.js', 'content/mikroTaxPatch136.js', 'content/targetRunner.js']
const GIB_LOGIN_URL = 'https://intvrg.gib.gov.tr/'
const GIB_TAB_PATTERN = 'https://intvrg.gib.gov.tr/*'
const GIB_SESSION_PATH = '/intvrg_side/main.jsp'
const GIB_APP_NAME = 'tdvd'
const hotelPanel = document.getElementById('hotel-panel')
const hotelDetails = document.getElementById('hotel-details')
const hotelStatus = document.getElementById('hotel-status')
const hotelCount = document.getElementById('hotel-count')
const hotelFile = document.getElementById('hotel-file')
const hotelTemplate = document.getElementById('hotel-template')
const hotelTemplatePreview = document.getElementById('hotel-template-preview')
const hotelCheckTemplateButton = document.getElementById('hotel-check-template')
const hotelCity = document.getElementById('hotel-city')
const hotelDistrict = document.getElementById('hotel-district')
const hotelImportButton = document.getElementById('hotel-import')
const hotelFillButton = document.getElementById('hotel-fill-next')
const hotelClearButton = document.getElementById('hotel-clear')
let latestState = null

function money(value) {
  return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(Number(value) || 0)
}

function dateTime(value) {
  if (!value) return '-'
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? '-' : date.toLocaleString('tr-TR')
}

function setStatus(message, error = false) {
  status.textContent = message
  status.classList.toggle('error', error)
}

function appendDefinition(list, label, value) {
  const term = document.createElement('dt')
  term.textContent = label
  const description = document.createElement('dd')
  description.textContent = String(value ?? '-') || '-'
  list.append(term, description)
}

function setHotelStatus(message, kind = 'info') {
  hotelStatus.textContent = message
  hotelStatus.dataset.kind = kind
}

function selectedHotelTemplateKey() {
  return String(hotelTemplate?.value || 'auto')
}

function renderHotelTemplatePreview(result) {
  hotelTemplatePreview.replaceChildren()
  const first = result?.rows?.[0] || null
  if (!first) {
    hotelTemplatePreview.hidden = true
    return
  }
  appendDefinition(hotelTemplatePreview, 'Şablon', result.templateLabel || result.templateKey || '-')
  appendDefinition(hotelTemplatePreview, 'İlk misafir', first.fullName || `${first.firstName} ${first.lastName}`)
  appendDefinition(hotelTemplatePreview, 'Kimlik', first.identityMode === 'foreign' ? `${first.identityNo} · Yabancı` : first.identityNo)
  appendDefinition(hotelTemplatePreview, 'Tutar', money(first.grossAmount))
  appendDefinition(hotelTemplatePreview, 'Açıklama', first.description || 'Eski şablonda tarih/oda açıklaması yok.')
  hotelTemplatePreview.hidden = false
}

async function inspectSelectedHotelFile({ announce = true } = {}) {
  const file = hotelFile.files?.[0]
  if (!file) throw new Error('Önce .xlsx, .csv veya .tsv dosyası seçin.')
  if (announce) setHotelStatus('Şablon ve ilk satır kontrol ediliyor…')
  const result = await inspectHotelInvoiceFile(file, { templateKey: selectedHotelTemplateKey() })
  renderHotelTemplatePreview(result)
  if (announce) setHotelStatus(`${result.rows.length} kişi · ${result.templateLabel} doğrulandı.`, 'success')
  return result
}

async function checkHotelTemplate() {
  hotelCheckTemplateButton.disabled = true
  try {
    await inspectSelectedHotelFile({ announce: true })
  } catch (error) {
    hotelTemplatePreview.hidden = true
    setHotelStatus(error?.message || 'Hotel şablonu kontrol edilemedi.', 'error')
  } finally {
    hotelCheckTemplateButton.disabled = false
  }
}

function renderHotelQueue(queue) {
  hotelDetails.replaceChildren()
  const rows = Array.isArray(queue?.rows) ? queue.rows : []
  const completed = rows.filter((row) => row.status === 'filled').length
  const current = rows.find((row) => row.status !== 'filled') || null
  hotelCount.textContent = `${completed} / ${rows.length}`
  appendDefinition(hotelDetails, 'Dosya', queue?.fileName || '-')
  appendDefinition(hotelDetails, 'Şablon', queue?.templateLabel || queue?.templateKey || '-')
  appendDefinition(hotelDetails, 'İl / İlçe', queue ? `${queue.city} / ${queue.district}` : '-')
  appendDefinition(hotelDetails, 'Sıradaki', current ? `${current.firstName} ${current.lastName}` : '-')
  appendDefinition(hotelDetails, 'Kimlik', current ? current.identityNo : '-')
  appendDefinition(hotelDetails, 'Ödenecek tutar', current ? money(current.grossAmount) : '-')
  appendDefinition(hotelDetails, 'Açıklama', current?.description || '-')
  appendDefinition(hotelDetails, 'Birim fiyat', current ? `${current.unitPrice.toLocaleString('tr-TR', { minimumFractionDigits: 3, maximumFractionDigits: 3 })} TL` : '-')
  hotelFillButton.disabled = !current || current.status === 'prepared' || !latestState?.session
  hotelClearButton.disabled = !rows.length
  if (!rows.length) setHotelStatus('Henüz liste yüklenmedi.')
  else if (!current) setHotelStatus(`${rows.length} kişinin tamamında Gönder düğmesine basıldı. Resmî sonuçları Mikro ePortal’dan kontrol edin.`, 'success')
  else if (current.status === 'prepared') setHotelStatus(`${current.firstName} ${current.lastName} formu ve ödenecek tutarı doğrulandı. Sıra, Mikro ePortal’daki Gönder düğmesine tıklayınca ilerleyecek.`)
  else setHotelStatus(`${completed + 1}. kişi hazır: ${current.firstName} ${current.lastName}. Mikro ePortal’da yeni fatura ekranındayken doldurun.`)
}

async function loadHotelQueue() {
  const response = await chrome.runtime.sendMessage({ type: 'RCN_HOTEL_QUEUE_GET' })
  if (!response?.ok) throw new Error(response?.error || 'Hotel listesi okunamadı.')
  renderHotelQueue(response.result)
  return response.result
}

async function importHotelQueue() {
  const file = hotelFile.files?.[0]
  if (!file) return setHotelStatus('Önce .xlsx, .csv veya .tsv dosyası seçin.', 'error')
  const city = hotelCity.value.trim()
  const district = hotelDistrict.value.trim()
  if (!city || !district) return setHotelStatus('İl ve ilçe zorunludur.', 'error')
  const existingRows = latestState?.hotelQueue?.rows || []
  if (existingRows.some((row) => row.status !== 'filled') && !confirm('Mevcut tamamlanmamış Hotel listesi yeni dosyayla değiştirilsin mi?')) return
  hotelImportButton.disabled = true
  setHotelStatus('Excel listesi kontrol ediliyor…')
  try {
    const inspection = await inspectSelectedHotelFile({ announce: false })
    const rows = inspection.rows
    const response = await chrome.runtime.sendMessage({
      type: 'RCN_HOTEL_QUEUE_IMPORT',
      fileName: file.name,
      city,
      district,
      templateKey: inspection.templateKey,
      templateLabel: inspection.templateLabel,
      rows,
    })
    if (!response?.ok) throw new Error(response?.error || 'Hotel listesi yüklenemedi.')
    latestState = { ...(latestState || {}), hotelQueue: response.result }
    renderHotelQueue(response.result)
    renderHotelTemplatePreview(inspection)
    setHotelStatus(`${rows.length} kişi yüklendi · ${inspection.templateLabel}. İlk kişi doldurulmaya hazır.`, 'success')
  } catch (error) {
    setHotelStatus(error?.message || 'Excel listesi okunamadı.', 'error')
  } finally {
    hotelImportButton.disabled = false
  }
}

async function fillNextHotelInvoice() {
  hotelFillButton.disabled = true
  setHotelStatus('Sıradaki kişi Mikro ePortal için hazırlanıyor…')
  try {
    await ensureMikroReceiver()
    const response = await chrome.runtime.sendMessage({ type: 'RCN_HOTEL_FILL_NEXT' })
    if (!response?.ok) throw new Error(response?.error || 'Sıradaki Hotel faturası açılamadı.')
    setHotelStatus(`${response.result.recipientTitle} için önizleme açıldı. Hedef sayfadaki “Formu Doldur” düğmesini kullanın.`, 'success')
  } catch (error) {
    setHotelStatus(error?.message || 'Sıradaki kişi doldurulamadı.', 'error')
    hotelFillButton.disabled = false
  }
}

async function clearHotelQueue() {
  if (!confirm('Yüklenen Hotel fatura listesi ve ilerleme bilgisi temizlensin mi?')) return
  const response = await chrome.runtime.sendMessage({ type: 'RCN_HOTEL_QUEUE_CLEAR' })
  if (!response?.ok) return setHotelStatus(response?.error || 'Hotel listesi temizlenemedi.', 'error')
  latestState = { ...(latestState || {}), hotelQueue: null }
  renderHotelQueue(null)
  hotelFile.value = ''
}

function permissionLabel(permission) {
  const labels = {
    'mikrogroup_eportal:create_invoice_draft': 'Mikro ePortal taslağı',
    'device:web_serial': 'Web Serial',
    'device:web_hid': 'WebHID',
    'device:web_usb': 'WebUSB',
    'device:camera': 'Kamera',
    'device:browser_print': 'Tarayıcı yazdırma',
  }
  return labels[permission] || permission
}

function renderSession(session, pendingPairing) {
  sessionDetails.replaceChildren()
  permissionsRoot.replaceChildren()
  if (!session) {
    sessionBadge.textContent = pendingPairing ? 'Onay bekliyor' : 'Eşleştirilmemiş'
    sessionBadge.className = `badge ${pendingPairing ? 'warning' : 'muted'}`
    appendDefinition(sessionDetails, 'Bağlı kullanıcı', '-')
    appendDefinition(sessionDetails, 'Firma', '-')
    appendDefinition(sessionDetails, 'Şube', '-')
    appendDefinition(sessionDetails, 'Cihaz', pendingPairing?.deviceFingerprint ? `${pendingPairing.deviceFingerprint.slice(0, 12)}…` : '-')
    appendDefinition(sessionDetails, 'Durum', pendingPairing ? `Web onayı bekleniyor · ${dateTime(pendingPairing.expiresAt)}` : 'rCn web üzerinden eşleştirin')
    logoutButton.disabled = true
    return
  }
  sessionBadge.textContent = 'Bağlı'
  sessionBadge.className = 'badge success'
  appendDefinition(sessionDetails, 'Bağlı kullanıcı', session.profileName || session.profileId || '-')
  appendDefinition(sessionDetails, 'Firma', session.companyName || session.companyId)
  appendDefinition(sessionDetails, 'Şube', session.branchName || session.branchId || 'Tüm yetkili şubeler')
  appendDefinition(sessionDetails, 'Cihaz', `${session.deviceFingerprint.slice(0, 12)}…`)
  appendDefinition(sessionDetails, 'Oturum süresi', dateTime(session.expiresAt))
  for (const permission of session.permissionScopes || []) {
    const chip = document.createElement('span')
    chip.textContent = permissionLabel(permission)
    permissionsRoot.appendChild(chip)
  }
  logoutButton.disabled = false
}

function renderSystems(state) {
  systemDetails.replaceChildren()
  const rcnTabs = state.tabs?.rcn || []
  const targetTabs = state.tabs?.targets || []
  appendDefinition(systemDetails, 'Mevcut rCn web sekmesi', rcnTabs.length ? `${rcnTabs.length} açık sekme` : 'Açık değil')
  appendDefinition(systemDetails, 'Desteklenen hedef', state.profile?.name || 'Mikrogroup ePortal')
  appendDefinition(systemDetails, 'Hedef sekmesi', targetTabs.length ? `${targetTabs.length} açık sekme` : 'Açık değil')
  appendDefinition(systemDetails, 'Seçici sürümü', state.profile?.selectorVersion || 'Doğrulanmadı')
  const ledgerEntries = Object.values(state.ledger || {}).sort((first, second) => Date.parse(second.filledAt || second.previewedAt || second.capturedAt || 0) - Date.parse(first.filledAt || first.previewedAt || first.capturedAt || 0))
  const last = ledgerEntries[0]
  appendDefinition(systemDetails, 'Son işlem', last ? `${last.recipientTitle || 'Kayıt'} · ${last.status || '-'}` : 'Henüz işlem yok')
}

async function ensureMikroReceiver() {
  const tabs = await chrome.tabs.query({ url: MIKRO_TAB_PATTERN })
  const tab = tabs[0]
  if (!tab?.id || !chrome.scripting?.executeScript) return
  try {
    const probe = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => Boolean(globalThis.RcnMikroAdapter),
    })
    if (probe?.[0]?.result === true) return
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: MIKRO_CONTENT_FILES })
  } catch (_) {
    throw new Error('Mikro ePortal bağlantı bileşeni açık sekmeye yüklenemedi. Mikro sekmesini bir kez yenileyip tekrar deneyin.')
  }
}

async function openJob(operationKey, button) {
  button.disabled = true
  setStatus('Mikro ePortal açılıyor ve önizleme hazırlanıyor…')
  try {
    await ensureMikroReceiver()
    const response = await chrome.runtime.sendMessage({ type: 'RCN_OPEN_TARGET', operationKey })
    if (!response?.ok) throw new Error(response?.error || 'Mikro ePortal açılamadı.')
    setStatus('Mikro ePortal önizlemesi açıldı. Form ancak hedef sayfadaki onayınızla doldurulur.')
  } catch (error) {
    const raw = String(error?.message || '')
    const receivingEnd = /receiving end does not exist|could not establish connection/i.test(raw)
    setStatus(receivingEnd ? 'Mikro ePortal sekmesindeki rCn bağlantısı yüklenemedi. Sekmeyi yenileyip tekrar deneyin.' : (raw || 'Mikro ePortal açılamadı.'), true)
  } finally {
    button.disabled = false
  }
}

function renderJobs(jobs) {
  jobsRoot.replaceChildren()
  jobCount.textContent = String(jobs.length)
  if (!jobs.length) {
    const empty = document.createElement('div')
    empty.className = 'empty'
    empty.textContent = 'Bekleyen aktarım yok. rCn satış detayından sunucu onaylı ePortal işi oluşturun.'
    jobsRoot.appendChild(empty)
    return
  }
  for (const job of jobs) {
    const article = document.createElement('article')
    article.className = 'job'
    const invoice = job.invoice
    const heading = document.createElement('h3')
    heading.textContent = invoice.recipient.title
    const list = document.createElement('dl')
    appendDefinition(list, 'Belge', invoice.document.label)
    appendDefinition(list, 'Kalem', invoice.lines.length)
    appendDefinition(list, 'Toplam', money(invoice.totals.gross))
    appendDefinition(list, 'Ödeme', invoice.payment.label)
    appendDefinition(list, 'Süre', dateTime(job.expiresAt))
    const button = document.createElement('button')
    button.type = 'button'
    button.className = 'primary'
    button.textContent = 'ePortal’ı Aç ve Önizle'
    button.addEventListener('click', () => openJob(job.operationKey, button))
    article.append(heading, list, button)
    jobsRoot.appendChild(article)
  }
}

async function load() {
  setStatus('rCn bağlantısı ve aktarım kuyruğu kontrol ediliyor…')
  const response = await chrome.runtime.sendMessage({ type: 'RCN_GET_STATE' })
  if (!response?.ok) {
    setStatus(response?.error || 'Eklenti durumu alınamadı.', true)
    return
  }
  const state = response.result
  latestState = state
  renderSession(state.session, state.pendingPairing)
  renderSystems(state)
  renderJobs(state.jobs || [])
  renderHotelQueue(state.hotelQueue)
  if (!state.session) {
    setStatus(state.pendingPairing ? 'Cihaz bilgileri rCn web onayını bekliyor.' : 'Eklenti eşleştirilmemiş. rCn web’de Mikro ePortal alanından cihaz eşleştirmesini başlatın.', !state.pendingPairing)
  } else if (state.profile.selectorVersion === 'unverified') {
    setStatus('Cihaz oturumu bağlı. Mikro ePortal seçicileri henüz doğrulanmadığı için form doldurma güvenli biçimde durdurulur.')
  } else {
    setStatus(`${state.jobs.length} bekleyen iş var. Firma ve cihaz kapsamı doğrulandı.`)
  }
}

async function openWeb() {
  const response = await chrome.runtime.sendMessage({ type: 'RCN_OPEN_WEB' })
  if (!response?.ok) setStatus(response?.error || 'rCn web açılamadı.', true)
}

function isGibSessionTab(tab) {
  try {
    const url = new URL(String(tab?.url || ''))
    return url.origin === 'https://intvrg.gib.gov.tr'
      && url.pathname === GIB_SESSION_PATH
      && url.searchParams.get('appName') === GIB_APP_NAME
  } catch (_) {
    return false
  }
}

async function activateTab(tab) {
  await chrome.tabs.update(tab.id, { active: true })
  if (tab.windowId != null && chrome.windows?.update) {
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {})
  }
}

async function openGib() {
  try {
    const tabs = await chrome.tabs.query({ url: GIB_TAB_PATTERN })
    const sessionTab = tabs.find(isGibSessionTab)
    if (sessionTab?.id != null) {
      await activateTab(sessionTab)
      setStatus('Mevcut GİB İnternet Vergi Dairesi oturumu açıldı. ÖTV 2A ekranında rCn hazırlık paneli bu oturum üzerinde çalışır.')
      return
    }
    const existingTab = tabs[0]
    if (existingTab?.id != null) {
      await activateTab(existingTab)
      setStatus('GİB sekmesi açıldı. Girişi kullanıcı olarak tamamlayın; oturum açılınca rCn aynı main.jsp oturumunda çalışır.')
      return
    }
    await chrome.tabs.create({ url: GIB_LOGIN_URL, active: true })
    setStatus('GİB giriş sayfası açıldı. Giriş ve resmî onay adımları kullanıcı tarafından tamamlanır; rCn oturum sırrını kaydetmez.')
  } catch (error) {
    setStatus(error?.message || 'GİB İnternet Vergi Dairesi açılamadı.', true)
  }
}

async function openOptions() {
  try {
    await chrome.runtime.openOptionsPage()
  } catch (error) {
    setStatus(error.message || 'Mikro ePortal ayarları açılamadı.', true)
  }
}

async function logout() {
  logoutButton.disabled = true
  const response = await chrome.runtime.sendMessage({ type: 'RCN_LOGOUT_EXTENSION' })
  if (!response?.ok) setStatus(response?.error || 'Eklenti oturumu kapatılamadı.', true)
  else {
    setStatus('Eklenti cihaz oturumu kapatıldı. Web’deki bağlı cihaz kaydı ayrıca iptal edilebilir.')
    await load()
  }
}

document.getElementById('refresh').addEventListener('click', load)
document.getElementById('open-web').addEventListener('click', openWeb)
document.getElementById('manage-devices').addEventListener('click', openWeb)
document.getElementById('open-options').addEventListener('click', openOptions)
document.getElementById('toggle-hotel').addEventListener('click', async (event) => {
  const show = hotelPanel.hidden
  hotelPanel.hidden = !show
  event.currentTarget.setAttribute('aria-expanded', String(show))
  if (show) {
    try { await loadHotelQueue() } catch (error) { setHotelStatus(error?.message || 'Hotel listesi okunamadı.', 'error') }
    hotelPanel.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }
})
document.getElementById('open-gib').addEventListener('click', openGib)
hotelCheckTemplateButton.addEventListener('click', checkHotelTemplate)
hotelTemplate.addEventListener('change', () => {
  hotelTemplatePreview.hidden = true
  if (hotelFile.files?.[0]) setHotelStatus('Şablon seçimi değişti. “Şablonu Kontrol Et” ile dosyayı tekrar doğrulayın.')
})
hotelFile.addEventListener('change', () => {
  hotelTemplatePreview.hidden = true
  if (hotelFile.files?.[0]) setHotelStatus('Dosya seçildi. Yüklemeden önce “Şablonu Kontrol Et” ile ilk kaydı doğrulayabilirsiniz.')
})
hotelImportButton.addEventListener('click', importHotelQueue)
hotelFillButton.addEventListener('click', fillNextHotelInvoice)
hotelClearButton.addEventListener('click', clearHotelQueue)
logoutButton.addEventListener('click', logout)
load()
